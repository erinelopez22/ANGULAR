﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Helpers
{
    public class Config
    {
        public static string Server = "172.30.0.17";
        public static string Database = "Bookkeeping";
        public static string DbUser = "sapdb";
        public static string DbPwd = "sapdb";
        public static int ProgId = 256;
    }
}