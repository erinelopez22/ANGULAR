﻿using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Net.Http.Headers;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Data;
using Snapshot_API.DAL;
using Snapshot_API.Models;



namespace Snapshot_API.Controllers
{
    [RoutePrefix("api/fs")]
    public class FSController : ApiController
    {
        
        [Route("postData")]
        [HttpPost]
        public string post([FromBody]ForPostingModel SSFSH, string createdBy)
        {
            string Results = "";
            try
            {
                Results = DAL.dal_Snapshot.ForPost(SSFSH, createdBy);
                return Results;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("get")]
        public IHttpActionResult Get(int Yr, int Pd, string whcode)
        {

                  
            try
            {
                DataTable dt = DAL.dal_Snapshot.Get(Yr,Pd, whcode);
                
                List<ForPostingModel_BS> model = new List<ForPostingModel_BS>();
                List<ForPostingModel_IS> model2 = new List<ForPostingModel_IS>();
                var rep = new Models.ForPostingModel();
                if (dt != null)
                {

                    
                    DataRow[] Dtrows = dt.Select("TBType='BS'");
                    DataRow[] Dtrows2 = dt.Select("TBType='IS'");
                    model = (from DataRow dr in Dtrows
                             select new ForPostingModel_BS()
                             {

                                 Dscpt = Convert.ToString(dr["Dscpt"]),
                                 Blk = Convert.ToString(dr["Blk"]),
                                 Yr = Convert.ToInt32(dr["Yr"]),
                                 Pd = Convert.ToInt32(dr["Pd"]),
                                 BegAmt = dr["BegAmt"],
                                 EndAmt = dr["EndAmt"],
                                 CurrAmt = dr["CurrAmt"],
                                 wc = Convert.ToString(dr["WhsCode"]),
                                 DocDate = Convert.ToDateTime(dr["DocDate"]).ToShortDateString(),
                                 TBType = Convert.ToString(dr["TBType"]),
                                 DocEntry = Convert.ToInt32(dr["DocEntry"])

                             }).ToList();
                    model2 = (from DataRow dr in Dtrows2
                              select new ForPostingModel_IS()
                              {

                                  Dscpt = Convert.ToString(dr["Dscpt"]),
                                  Blk = Convert.ToString(dr["Blk"]),
                                  Yr = Convert.ToInt32(dr["Yr"]),
                                  Pd = Convert.ToInt32(dr["Pd"]),
                                  BegAmt = dr["BegAmt"],
                                  EndAmt = dr["EndAmt"],
                                  CurrAmt = dr["CurrAmt"],
                                  wc = Convert.ToString(dr["WhsCode"]),
                                  DocDate = Convert.ToDateTime(dr["DocDate"]).ToShortDateString(),
                                  TBType = Convert.ToString(dr["TBType"]),
                                  DocEntry = Convert.ToInt32(dr["DocEntry"])

                              }).ToList();
                    rep.BalSht = model;
                    rep.IncState = model2;
                    return Ok(rep);
                }
                return Ok(rep);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        
        

        [HttpGet]
        [Route("export")]
        public HttpResponseMessage export(int Fromyear, int pd1, int Toyear, int pd2, string whcode)
        {

            string fileName = string.Concat(DateTime.Now.ToString("SS_yyyyMMddmm") + ".xls");
            string filePath = HttpContext.Current.Server.MapPath("~/Report/" + fileName);

            string fileName1 = string.Concat(DateTime.Now.ToString("SSS_yyyyMMddmm") + ".xls");
            string filePath1 = HttpContext.Current.Server.MapPath("~/Report/" + fileName1);

            dal_Snapshot excl = new dal_Snapshot();
            DataTable dt = dal_Snapshot.ExportData(Fromyear, pd1, Toyear, pd2, whcode);
            HttpResponseMessage result = null;
            DAL.Extract nn = new DAL.Extract();
            if (dt != null)
            {
                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();
                
                DataRow[] Dtrows = dt.Select("Tbtype='BS'");
                DataRow[] Dtrows2 = dt.Select("Tbtype='IS'");
                model = (from DataRow dr in Dtrows
                         select new ExcelModel()
                            {

                                RowNo = Convert.ToInt32(dr["RowNo"]),
                                Dscpt = Convert.ToString(dr["Dscpt"]),
                                Blk = Convert.ToString(dr["Blk"]),
                                Yr = Convert.ToInt32(dr["Yr"]),
                                Pd = Convert.ToInt32(dr["Pd"]),
                                total = dr["Total"],
                                DocEntry = Convert.ToInt32(dr["DocEntry"]),
                                TBType = Convert.ToString(dr["TBType"]),
                                DscrptTop = Convert.ToString(dr["DscrptTop"]),
                                DscrptBot = Convert.ToString(dr["DscrptBot"]),
                                 Hrd=Convert.ToString(dr["EndFormula"]),
                                HrdFS = Convert.ToString(dr["DscrptFS"]),
                                HrdFC = Convert.ToString(dr["DscrptFC"]),
                                BegFormula = Convert.ToString(dr["BegFormula"]),
                                DscrptBG = Convert.ToString(dr["DscrptBG"])

                                
                            }).ToList();
                model2 = (from DataRow dr in Dtrows2
                         select new IS()
                         {

                             RowNo = Convert.ToInt32(dr["RowNo"]),
                             Dscpt = Convert.ToString(dr["Dscpt"]),
                             Blk = Convert.ToString(dr["Blk"]),
                             Yr = Convert.ToInt32(dr["Yr"]),
                             Pd = Convert.ToInt32(dr["Pd"]),
                             total = dr["Total"],
                             DocEntry = Convert.ToInt32(dr["DocEntry"]),
                             TBType = Convert.ToString(dr["TBType"]),
                             DscrptTop = Convert.ToString(dr["DscrptTop"]),
                             DscrptBot = Convert.ToString(dr["DscrptBot"]),
                             Hrd = Convert.ToString(dr["EndFormula"]),
                             HrdFS = Convert.ToString(dr["DscrptFS"]),
                                HrdFC = Convert.ToString(dr["DscrptFC"]),
                                BegFormula=Convert.ToString(dr["BegFormula"]),
                             DscrptBG = Convert.ToString(dr["DscrptBG"])
                         }).ToList();
                DataTable dt2 = dal_Snapshot.SS_DATA_(Fromyear, pd1, Toyear, pd2, whcode);
                DataTable dt3 = dal_Snapshot.SS_DATAwithFormula(whcode);
                nn.ExtractExcel(model, model2, filePath, dt2, dt3);


                result = Request.CreateResponse(HttpStatusCode.OK);
                result.Content = new StreamContent(new FileStream(filePath, FileMode.Open));
                result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                result.Content.Headers.ContentDisposition.FileName = fileName;


               //nn.ExtractExcel_(model, model2, filePath1, dt2, dt3);
            }
            return result; 
        }
        [HttpGet]
        [Route("view")]
        public IHttpActionResult view(int Fromyear, int pd1, int Toyear, int pd2, string whcode)
        {

              string fileName = string.Concat(DateTime.Now.ToString("SS_yyyyMMddmm") + ".xls");
              string filePath = HttpContext.Current.Server.MapPath("~/Report/" + fileName);

              dal_Snapshot excl = new dal_Snapshot();
              DataTable dt = dal_Snapshot.ExportData2(Fromyear, pd1, Toyear, pd2, whcode);
              DataTable dt2 = dal_Snapshot.SS_DATA_(Fromyear, pd1, Toyear, pd2, whcode);
              DAL.Extract nn = new DAL.Extract();
              var rep = new Models.DataRpt();

              if (dt != null)
              {
                  if (dt.Rows.Count >=1) { 
                  List<ExcelModel> model = new List<ExcelModel>();
                  List<IS> model2 = new List<IS>();

                  DataRow[] Dtrows = dt.Select("Tbtype='BS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                  DataRow[] Dtrows2 = dt.Select("Tbtype='IS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                  model = (from DataRow dr in Dtrows
                           select new ExcelModel()
                           {

                               RowNo = Convert.ToInt32(dr["RowNo"]),
                               Dscpt = Convert.ToString(dr["Dscpt"]),
                               Blk = Convert.ToString(dr["Blk"]),
                               Yr = Convert.ToInt32(dr["Yr"]),
                               Pd = Convert.ToInt32(dr["Pd"]),
                               total = string.Format("{0:#,0.00}", dr["Total"]),
                               DocEntry = Convert.ToInt32(dr["DocEntry"]),
                               TBType = Convert.ToString(dr["TBType"]),
                               DscrptTop = Convert.ToString(dr["DscrptTop"]),
                               DscrptBot = Convert.ToString(dr["DscrptBot"]),
                               Hrd = Convert.ToString(dr["EndFormula"]),
                               HrdFS = Convert.ToString(dr["DscrptFS"]),
                               HrdFC = Convert.ToString(dr["DscrptFC"]),
                               BegFormula = Convert.ToString(dr["BegFormula"]),
                               DscrptBG = Convert.ToString(dr["DscrptBG"])


                           }).ToList();
                  model2 = (from DataRow dr in Dtrows2
                            select new IS()
                            {

                                RowNo = Convert.ToInt32(dr["RowNo"]),
                                Dscpt = Convert.ToString(dr["Dscpt"]),
                                Blk = Convert.ToString(dr["Blk"]),
                                Yr = Convert.ToInt32(dr["Yr"]),
                                Pd = Convert.ToInt32(dr["Pd"]),
                                total = string.Format("{0:#,0.00}", dr["Total"]),
                                DocEntry = Convert.ToInt32(dr["DocEntry"]),
                                TBType = Convert.ToString(dr["TBType"]),
                                DscrptTop = Convert.ToString(dr["DscrptTop"]),
                                DscrptBot = Convert.ToString(dr["DscrptBot"]),
                                Hrd = Convert.ToString(dr["EndFormula"]),
                                HrdFS = Convert.ToString(dr["DscrptFS"]),
                                HrdFC = Convert.ToString(dr["DscrptFC"]),
                                BegFormula = Convert.ToString(dr["BegFormula"]),
                                DscrptBG = Convert.ToString(dr["DscrptBG"])
                            }).ToList();
                  //nn.ExtractExcel(model, model2, filePath);
                  rep.Snapshot = nn.ViewSnapshot(dt2);
                  rep.HDR = nn.HDR(model);
                  rep.BalSht=nn.ViewBalanceSheet(model);
                    rep.IncState=nn.ViewIncomeStatement(model2);
              }
              }
              return Ok(rep);
        }
        [HttpGet]
        [Route("SS_Rpt")]
        public IHttpActionResult SS_Rpt(int Fromyear, int pd1, int Toyear, int pd2, string whcode)
        {

            string fileName = string.Concat(DateTime.Now.ToString("SS_yyyyMMddmm") + ".xls");
            string filePath = HttpContext.Current.Server.MapPath("~/Report/" + fileName);

            dal_Snapshot excl = new dal_Snapshot();
            DataTable dt = dal_Snapshot.SS_DATA(Fromyear, pd1, Toyear, pd2, whcode);
            DAL.Extract nn = new DAL.Extract();
            var rep = new Models.DataRpt();

            if (dt != null)
            {

                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();

                DataRow[] Dtrows = dt.Select("Tbtype='BS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                DataRow[] Dtrows2 = dt.Select("Tbtype='IS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                model = (from DataRow dr in Dtrows
                         select new ExcelModel()
                         {

                             RowNo = Convert.ToInt32(dr["RowNo"]),
                             Dscpt = Convert.ToString(dr["Dscpt"]),
                             Blk = Convert.ToString(dr["Blk"]),
                             Yr = Convert.ToInt32(dr["Yr"]),
                             Pd = Convert.ToInt32(dr["Pd"]),
                             total = string.Format("{0:#,0.00}", dr["Total"]),
                             DocEntry = Convert.ToInt32(dr["DocEntry"]),
                             TBType = Convert.ToString(dr["TBType"]),
                             DscrptTop = Convert.ToString(dr["DscrptTop"]),
                             DscrptBot = Convert.ToString(dr["DscrptBot"]),
                             Hrd = Convert.ToString(dr["EndFormula"]),
                             HrdFS = Convert.ToString(dr["DscrptFS"]),
                             HrdFC = Convert.ToString(dr["DscrptFC"]),
                             BegFormula = Convert.ToString(dr["BegFormula"]),
                             DscrptBG = Convert.ToString(dr["DscrptBG"])


                         }).ToList();
                model2 = (from DataRow dr in Dtrows2
                          select new IS()
                          {

                              RowNo = Convert.ToInt32(dr["RowNo"]),
                              Dscpt = Convert.ToString(dr["Dscpt"]),
                              Blk = Convert.ToString(dr["Blk"]),
                              Yr = Convert.ToInt32(dr["Yr"]),
                              Pd = Convert.ToInt32(dr["Pd"]),
                              total = string.Format("{0:#,0.00}", dr["Total"]),
                              DocEntry = Convert.ToInt32(dr["DocEntry"]),
                              TBType = Convert.ToString(dr["TBType"]),
                              DscrptTop = Convert.ToString(dr["DscrptTop"]),
                              DscrptBot = Convert.ToString(dr["DscrptBot"]),
                              Hrd = Convert.ToString(dr["EndFormula"]),
                              HrdFS = Convert.ToString(dr["DscrptFS"]),
                              HrdFC = Convert.ToString(dr["DscrptFC"]),
                              BegFormula = Convert.ToString(dr["BegFormula"]),
                              DscrptBG = Convert.ToString(dr["DscrptBG"])
                          }).ToList();
                //nn.ExtractExcel(model, model2, filePath);

                rep.HDR = nn.HDR(model);
                rep.BalSht = nn.ViewBalanceSheet(model);
                rep.IncState = nn.ViewIncomeStatement(model2);
            }

            return Ok(rep);
        }
        [HttpGet]
        [Route("SS_Exl")]
        public IHttpActionResult SS_Exl(int Fromyear, int pd1, int Toyear, int pd2, string whcode)
        {

            string fileName = string.Concat(DateTime.Now.ToString("SS_yyyyMMddmm") + ".xls");
            string filePath = HttpContext.Current.Server.MapPath("~/Report/" + fileName);

            dal_Snapshot excl = new dal_Snapshot();
            DataTable dt = dal_Snapshot.SS_DATA(Fromyear, pd1, Toyear, pd2, whcode);
            DAL.Extract nn = new DAL.Extract();
            var rep = new Models.DataRpt();

            if (dt != null)
            {

                List<ExcelModel> model = new List<ExcelModel>();
                List<IS> model2 = new List<IS>();

                DataRow[] Dtrows = dt.Select("Tbtype='BS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                DataRow[] Dtrows2 = dt.Select("Tbtype='IS' AND BegFormula=NULL OR BegFormula='' AND EndFormula <>'H' ");
                model = (from DataRow dr in Dtrows
                         select new ExcelModel()
                         {

                             RowNo = Convert.ToInt32(dr["RowNo"]),
                             Dscpt = Convert.ToString(dr["Dscpt"]),
                             Blk = Convert.ToString(dr["Blk"]),
                             Yr = Convert.ToInt32(dr["Yr"]),
                             Pd = Convert.ToInt32(dr["Pd"]),
                             total = string.Format("{0:#,0.00}", dr["Total"]),
                             DocEntry = Convert.ToInt32(dr["DocEntry"]),
                             TBType = Convert.ToString(dr["TBType"]),
                             DscrptTop = Convert.ToString(dr["DscrptTop"]),
                             DscrptBot = Convert.ToString(dr["DscrptBot"]),
                             Hrd = Convert.ToString(dr["EndFormula"]),
                             HrdFS = Convert.ToString(dr["DscrptFS"]),
                             HrdFC = Convert.ToString(dr["DscrptFC"]),
                             BegFormula = Convert.ToString(dr["BegFormula"]),
                             DscrptBG = Convert.ToString(dr["DscrptBG"])


                         }).ToList();
                model2 = (from DataRow dr in Dtrows2
                          select new IS()
                          {

                              RowNo = Convert.ToInt32(dr["RowNo"]),
                              Dscpt = Convert.ToString(dr["Dscpt"]),
                              Blk = Convert.ToString(dr["Blk"]),
                              Yr = Convert.ToInt32(dr["Yr"]),
                              Pd = Convert.ToInt32(dr["Pd"]),
                              total = string.Format("{0:#,0.00}", dr["Total"]),
                              DocEntry = Convert.ToInt32(dr["DocEntry"]),
                              TBType = Convert.ToString(dr["TBType"]),
                              DscrptTop = Convert.ToString(dr["DscrptTop"]),
                              DscrptBot = Convert.ToString(dr["DscrptBot"]),
                              Hrd = Convert.ToString(dr["EndFormula"]),
                              HrdFS = Convert.ToString(dr["DscrptFS"]),
                              HrdFC = Convert.ToString(dr["DscrptFC"]),
                              BegFormula = Convert.ToString(dr["BegFormula"]),
                              DscrptBG = Convert.ToString(dr["DscrptBG"])
                          }).ToList();
                //nn.ExtractExcel(model, model2, filePath);

                rep.HDR = nn.HDR(model);
                rep.BalSht = nn.ViewBalanceSheet(model);
                rep.IncState = nn.ViewIncomeStatement(model2);
            }

            return Ok(rep);
        }
        [HttpGet]
        [Route("headers")]
        public IHttpActionResult getHeader([FromUri]int year, [FromUri]string whcd)
        {
                
            try
            {
                List<object> model = DAL.dal_Snapshot.GetHdr(year, whcd);
                return Ok(model);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("details")]
        public IHttpActionResult getDetails([FromUri] int docnum)
        {

            try
            {
                List<object> model = DAL.dal_Snapshot.GetDet(docnum);
                return Ok(model);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
    
    }
}