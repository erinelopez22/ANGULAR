﻿using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Net.Http.Headers;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Data;
using Snapshot_API.DAL;
using Snapshot_API.Models;
using System.Collections.Generic;
using Microsoft.Owin;



namespace Snapshot_API.Controllers
{
    [RoutePrefix("api/tagging")]
    public class TaggingController : ApiController
    {

       
        [HttpGet]
        [Route("GetSSDesc")]
        public DataTable GetSSDesc(string whcode)
        {

            DataTable dt=new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getSSDesc(whcode);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }

        [HttpGet]
        [Route("GetAllTagged")]
        public DataTable GetAllTagged(int docEntry, string whcode)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getAllTagged(docEntry, whcode);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }

        [HttpGet]
        [Route("GetIS")]
        public DataTable GetIS(string whcode)
        {

            DataTable dt = new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getIS(whcode);
                if (dt.Rows.Count > 0) { return dt; }
                else
                {

                    dt.Rows.Add();
                    dt.Rows[0][0] = 0;
                    dt.Rows[0][1] = "NoData";
                    dt.Rows[0][2] = "NoData";
                    return dt;
                }
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }

        [HttpGet]
        [Route("GetSS")]
        public DataTable GetSS(string whcode)
        {

            DataTable dt = new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getSS(whcode);
                if (dt.Rows.Count > 0) { return dt; }
                else
                {

                    dt.Rows.Add();
                    dt.Rows[0][0] = 0;
                    dt.Rows[0][1] = "NoData";
                    dt.Rows[0][2] = "NoData";
                    return dt;
                }
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }

        [HttpGet]
        [Route("GetBS")]
        public DataTable GetBS(string whcode)
        {

            DataTable dt = new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getBS(whcode);
                if (dt.Rows.Count > 0) { return dt; }
                else
                {
                    
                    dt.Rows.Add();
                    dt.Rows[0][0] = 0;
                    dt.Rows[0][1]="NoData";
                    dt.Rows[0][2] = "NoData";
                    return dt;
                }
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }
        [HttpGet]
        [Route("GetTagged")]
        public DataTable GetTagged(string whcode,int docEntry)
        {

            DataTable dt = new DataTable();
            try
            {
                dt = DAL.dal_Tagging.getTagged(whcode, docEntry);
                if (dt.Rows.Count > 0) { return dt; }
                else
                {

                }
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return dt;
        }
        [HttpPost]
        [Route("AddTagged")]
        public string AddTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_, int HasFormula)
        {
            string res = "";
            try
            {
                res = DAL.dal_Tagging.addTagged(WhsCode, DocEntry, SS_DocEntry, Type_, HasFormula);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return res;
        }
        
        [HttpDelete]
        [Route("RemoveTagged")]
        public string RemoveTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_)
        {

            string res = "";
            try
            {
                res = DAL.dal_Tagging.removeTagged(WhsCode, DocEntry, SS_DocEntry, Type_);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
            return res;
        }
    }
}
