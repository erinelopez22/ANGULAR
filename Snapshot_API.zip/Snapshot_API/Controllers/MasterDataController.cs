﻿using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Snapshot_API.Controllers
{
    [RoutePrefix("api/masterdata")]
    public class MasterDataController : ApiController
    {
        [HttpGet]
        [Route("employees")]
        public IHttpActionResult GetEmployees()
        {
            try
            {
                List<object> model = DAL.dal_MasterData.Employees();
                return Ok(model);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
        [HttpGet]
        [Route("branches")]
        public IHttpActionResult branches()
        {
            try
            {
                List<object> model = DAL.dal_MasterData.branches_();
                return Ok(model);
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.Message, System.Text.Encoding.UTF8, "text/plain"),
                    StatusCode = HttpStatusCode.InternalServerError,
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(response);
            }
        }
    }
}
