﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Snapshot_API.Models
{
  

    public class ForPostingModel_BS
    {
        public string Blk { get; set; }
        public string Dscpt { get; set; }
        public string wc { get; set; }
        public int Yr { get; set; }
        public int Pd { get; set; }
        public object BegAmt { get; set; }
        public object EndAmt { get; set; }

        public object CurrAmt { get; set; }
        public string DocDate { get; set; }

        public int DocEntry { get; set; }
        public string TBType { get; set; }
        
                
    }
    public class ForPostingModel_IS
    {
        public string Blk { get; set; }
        public string Dscpt { get; set; }

        public string wc { get; set; }
        public int Yr { get; set; }
        public int Pd { get; set; }
        public object BegAmt { get; set; }
        public object EndAmt { get; set; }

        public object CurrAmt { get; set; }
        public string DocDate { get; set; }
        public int DocEntry { get; set; }
        public string TBType { get; set; }


    }
    public class ForPostingModel
    {
        public List<ForPostingModel_BS> BalSht { get; set; }
        public List<ForPostingModel_IS> IncState { get; set; }
    }
}