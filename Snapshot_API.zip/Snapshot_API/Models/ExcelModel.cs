﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Snapshot_API.Models
{
    public class ExcelModel2
    {
        public List<ExcelModel> BalSht { get; set; }
        public List<IS> IncState { get; set; }
    }
    public class DataRpt
    {
        public DataTable BalSht { get; set; }
        public DataTable IncState { get; set; }
        public DataTable HDR { get; set; }
        public DataTable Snapshot { get; set; }
    }
    public class ExcelModel
    {
           public int RowNo { get; set; }
           public string Dscpt { get; set; }
           public string Blk { get; set; }
           public int Yr { get; set; }
           public int Pd { get; set; }
           public object total { get; set; }

           public int DocEntry { get; set; }

        public string TBType { get; set; }
        public string DscrptTop { get; set; }
        public string DscrptBot { get; set; }
        public string Hrd { get; set; }
        public string HrdFS { get; set; }
        public string HrdFC { get; set; }
        public string BegFormula { get; set; }
        public string DscrptBG { get; set; }
                
    }
    public class IS
    {
        public int RowNo { get; set; }
        public string Dscpt { get; set; }
        public string Blk { get; set; }
        public int Yr { get; set; }
        public int Pd { get; set; }
        public object total { get; set; }

        public int DocEntry { get; set; }

        public string TBType { get; set; }
        public string DscrptTop { get; set; }
        public string DscrptBot { get; set; }
        public string Hrd { get; set; }
        public string HrdFS { get; set; }
        public string HrdFC { get; set; }
        public string BegFormula { get; set; }
        public string DscrptBG { get; set; }
  
    }

    public class SS
    {
        public int RowNo { get; set; }

        public int SS_DocEntry { get; set; }
        public string Descrip { get; set; }

        public Object TotalAmount { get; set; }
        public string WhsCode { get; set; }
        public string Type { get; set; }
        public int Yr { get; set; }
        public int Pd { get; set; }
        public string ColBot { get; set; }

        public string DescripFC { get; set; }
        public string DescripBG { get; set; }

        public string ColFC { get; set; }
        public string ColBG { get; set; }

    }
}