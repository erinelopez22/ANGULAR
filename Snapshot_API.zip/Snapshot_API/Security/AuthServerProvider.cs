﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Owin.Security.OAuth;
using System.Threading.Tasks;
using System.Security.Claims;
using Snapshot_API.Models;
using System.Threading;

namespace Snapshot_API.Security
{
    public class AuthServerProvider : OAuthAuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }

        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            ClaimsIdentity identity = new ClaimsIdentity(context.Options.AuthenticationType);
            try
            {
                User model = Snapshot_API.DAL.dal_Auth.Login(context.UserName, context.Password);
                identity.AddClaim(new Claim(ClaimTypes.Role, model.Role));
                identity.AddClaim(new Claim(ClaimTypes.GivenName, model.FName));
                identity.AddClaim(new Claim(ClaimTypes.Name, model.EmpName));
                identity.AddClaim(new Claim(ClaimTypes.Sid, model.EmpID));
                identity.AddClaim(new Claim("Dept", model.Dept));
                identity.AddClaim(new Claim("DeptCode", model.DeptCode.ToString()));
                identity.AddClaim(new Claim("SecCode", model.SecCode.ToString()));
                identity.AddClaim(new Claim("WhsCode", model.WhsCode));
                identity.AddClaim(new Claim("UType", model.UType));
                context.Validated(identity);
            }
            catch (Exception ex)
            {
                context.SetError("invalid_grant", ex.Message);
                return;
            }
        }
    }
}