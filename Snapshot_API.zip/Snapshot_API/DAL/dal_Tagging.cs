﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Snapshot_API.Helpers;
using Snapshot_API.Models;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Excel = Microsoft.Office.Interop.Excel;

namespace Snapshot_API.DAL
{
    public class dal_Tagging
    {

        public static DataTable getSSDesc(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str, 
                                            new SqlParameter("@mode", "SelectSS_Desc"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;  
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getAllTagged(int docEntry,string wc)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", "SelectAllTagged"),
                                            new SqlParameter("@WhsCode", wc),
                                            new SqlParameter("@DocEntry", null),
                                            new SqlParameter("@SS_DocEntry", docEntry),
                                            new SqlParameter("@Type", ""),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }


        public static DataTable getIS(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("IS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))

                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public static DataTable getSS(string WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("SS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getBS(String WhsCode)
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry, @SS_DocEntry, @Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode",Convert.ToString("BS_DESC")),
                                            new SqlParameter("@WhsCode", Convert.ToString(WhsCode)),
                                            new SqlParameter("@DocEntry",Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static DataTable getTagged(string wc,int docEntry )
        {
            try
            {
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry, @SS_DocEntry, @Type,@HasFormula";
                DataTable dt = tool.sqlDT(str,
                                            new SqlParameter("@mode", Convert.ToString("getDesc")),
                                            new SqlParameter("@WhsCode", Convert.ToString(wc)),
                                            new SqlParameter("@DocEntry", Convert.ToInt32(0)),
                                            new SqlParameter("@SS_DocEntry", Convert.ToInt32(docEntry)),
                                            new SqlParameter("@Type", Convert.ToString("")),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );

                tool.Dispose();
                return dt;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
        public static string addTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_,int hasformula)
        { 
            string res = "";
            try
            {
               
                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                tool.sqlExecute(str,
                                            new SqlParameter("@mode", "AddTagged"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", DocEntry),
                                            new SqlParameter("@SS_DocEntry", SS_DocEntry),
                                            new SqlParameter("@Type", Type_),
                                            new SqlParameter("@HasFormula", hasformula)
                                            );
                

                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }


        public static string removeTagged(string WhsCode, int DocEntry, int SS_DocEntry, string Type_)
        {
            string res = "";
            try
            {

                SQLTool tool = new SQLTool(Config.Server, Config.Database, Config.DbUser, Config.DbPwd);
                string str = "exec Bookkeeping.dbo.[sp_snap_Tagging] @mode, @WhsCode, @DocEntry,@SS_DocEntry,@Type,@HasFormula";
                tool.sqlExecute(str,
                                            new SqlParameter("@mode", "RemoveTagged"),
                                            new SqlParameter("@WhsCode", WhsCode),
                                            new SqlParameter("@DocEntry", DocEntry),
                                            new SqlParameter("@SS_DocEntry", SS_DocEntry),
                                            new SqlParameter("@Type", Type_),
                                            new SqlParameter("@HasFormula", Convert.ToInt32(0))
                                            );
                tool.Dispose();
                res = "Success";
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
                res = ex.Message.ToString();
            }
            return res;
        }
    }
}