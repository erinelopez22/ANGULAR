﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Drawing;
using Snapshot_API.Models;
using Snapshot_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using System.Web;
using System.IO;
using System.Net.Http.Headers;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Data;
using Snapshot_API.DAL;
using Snapshot_API.Models;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;

namespace Snapshot_API.DAL
{
    public class Extract
    {
        public void ExtractExcel(List<ExcelModel> datasource, List<IS> IS, string filePath, DataTable dt2, DataTable dt3)
        {
            DAL.Extract nn = new DAL.Extract();
            //return Task.Run(() =>
            {
                using (ExcelPackage pck = new ExcelPackage())
                {
                   List<SS> SS =nn.ViewSnapshotwithVal(dt2);
                   List<SS> SS2= nn.ViewSnapshotWithFormula(dt3);
                   _Snapshot(pck, SS, SS2);
                    
                    BalanceSheet(pck,datasource);
                    _IncomeStatement(pck,IS);
                    pck.SaveAs(new FileInfo(filePath));
                }
            }
        }
        public void ExtractExcel_(List<ExcelModel> datasource, List<IS> IS, string filePath, DataTable dt2, DataTable dt3)
        {
            DAL.Extract nn = new DAL.Extract();
            //return Task.Run(() =>
            
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook excelBook = excelApp.Workbooks.Add(1);


                Excel.Worksheet ws2 = (Excel.Worksheet)excelBook.Worksheets.Add();
                ws2.Name = "IS";
                IncomeStatement_(ws2, IS);
                ws2.Columns.AutoFit();

                Excel.Worksheet ws3 = (Excel.Worksheet)excelBook.Worksheets.Add();
                ws3.Name = "Balance Sheet";
                BalanceSheet_(ws3, datasource);
                ws3.Columns.AutoFit();

                Excel.Worksheet ws = (Excel.Worksheet)excelBook.Worksheets.Add();
                ws.Name = "Snapshot";
                List<SS> SS = nn.ViewSnapshotwithVal(dt2);
                List<SS> SS2 = nn.ViewSnapshotWithFormula(dt3);
                Snapshot_(ws, SS, SS2);
                ws.Columns.AutoFit();
                    
                    
                excelBook.SaveAs(new FileInfo(filePath));
 
       }
        public DataTable ViewIncomeStatement(List<IS> datasource)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 

            var col_ = 2;
            int colCnt = 1;
            DataTable IS = new DataTable();
            IS.Columns.Add("Description");
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                string month = GetPeriod(item.Pd);
                IS.Columns.Add(string.Format("{0} {1}", month, item.Yr));
                col_++;
                colCnt += 1;
            }

            
            int rowCnt = 0;
            foreach (var item in datasource.Select(x => new {  x.Dscpt, x.DocEntry }).Distinct())
            {
                IS.Rows.Add();
                IS.Rows[rowCnt][0] = item.Dscpt;
                int col = 1;
                foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                {

                    IS.Rows[rowCnt][col] = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();

                    col += 1;
                }
                rowCnt += 1;
            }
            return IS;
        }
        public List<SS> SS_DT_To_LIST(DataTable dt)
        {

            List<SS> model = new List<SS>();

            model = (from DataRow dr in dt.Rows
                     select new SS()
                     {
                         RowNo = Convert.ToInt32(dr["RowNo"]),
                         SS_DocEntry = Convert.ToInt32(dr["SS_DocEntry"]),
                         Descrip = Convert.ToString(dr["Descrip"]),
                         TotalAmount = string.Format("{0:#,0.00}", dr["TotalAmount"]),
                         WhsCode = Convert.ToString(dr["WhsCode"]),
                         Type = Convert.ToString(dr["Type"]),
                         Yr = Convert.ToInt32(dr["Yr"]),
                         Pd = Convert.ToInt32(dr["Pd"]),
                         ColBot = "",
                         DescripFC = Convert.ToString(dr["DescripFC"]),
                         DescripBG = Convert.ToString(dr["DescripBG"]),
                         ColFC = Convert.ToString(dr["ColFC"]),
                         ColBG = Convert.ToString(dr["ColBG"])

                     }).ToList();
            return model;
        }
        public List<SS> SS_DT_To_LIST2(DataTable dt)
        {

            List<SS> model = new List<SS>();

            model = (from DataRow dr in dt.Rows
                     select new SS()
                     {
                         RowNo = Convert.ToInt32(dr["RowNo"]),
                         SS_DocEntry = Convert.ToInt32(dr["SS_DocEntry"]),
                         Descrip = Convert.ToString(dr["Descrip"]),
                         TotalAmount = string.Format("{0:#,0.00}", dr["TotalAmount"]),
                         WhsCode = Convert.ToString(dr["WhsCode"]),
                         Type = Convert.ToString(dr["Type"]),
                         Yr = Convert.ToInt32(dr["Yr"]),
                         Pd = Convert.ToInt32(dr["Pd"]),
                         ColBot = Convert.ToString(dr["ColBot"]),
                         DescripFC = Convert.ToString(dr["DescripFC"]),
                         DescripBG = Convert.ToString(dr["DescripBG"]),
                         ColFC = Convert.ToString(dr["ColFC"]),
                         ColBG = Convert.ToString(dr["ColBG"])

                     }).ToList();
            return model;
        }
        public DataTable ViewSnapshot(DataTable dt)
        {

            List<SS> datasource = SS_DT_To_LIST(dt);
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 

            var col_ = 2;
            int colCnt = 1;
            DataTable SS = new DataTable();
            SS.Columns.Add("Description");
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                string month = GetPeriod(item.Pd);
                SS.Columns.Add(string.Format("{0} {1}", month, item.Yr));
                col_++;
                colCnt += 1;
            }


            int rowCnt = 0;
            foreach (var item in datasource.Select(x => new { x.Descrip, x.SS_DocEntry }).Distinct())
            {
                SS.Rows.Add();
                string a = item.Descrip;
                SS.Rows[rowCnt][0] = item.Descrip;
                int col = 1;
                foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                {

                    SS.Rows[rowCnt][col] = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.SS_DocEntry == item.SS_DocEntry).Select(x => x.TotalAmount).DefaultIfEmpty().SingleOrDefault();

                    col += 1;
                }
                rowCnt += 1;
            }
            DataView view = new DataView(SS);
            DataTable distinctValues = view.ToTable(true, "Description");
            return SS;
        }

        public List<SS> ViewSnapshotwithVal(DataTable dt)
        {

            List<SS> datasource = SS_DT_To_LIST(dt);
            return datasource;
        }
        public List<SS> ViewSnapshotWithFormula(DataTable dt)
        {

            List<SS> datasource = SS_DT_To_LIST2(dt);
            return datasource;
        }
        public DataTable ViewBalanceSheet(List<ExcelModel> datasource)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
            
            var col_ = 2;
            int colCnt = 1;
            DataTable BS = new DataTable();
            BS.Columns.Add("Description");
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                string month = GetPeriod(item.Pd);
                BS.Columns.Add(string.Format("{0} {1}", month, item.Yr));
                col_++;
                colCnt += 1;
            }

            
            int rowCnt = 0;
            foreach (var item in datasource.Select(x => new { x.Dscpt, x.DocEntry }).Distinct())
            {
                BS.Rows.Add();
                string a=item.Dscpt;
                BS.Rows[rowCnt][0] = item.Dscpt;
                int col = 1;
                foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                {

                    BS.Rows[rowCnt][col] = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                   
                     col+=1;
                }
                rowCnt+=1;
            }
            DataView view = new DataView(BS);
            DataTable distinctValues = view.ToTable(true,  "Description");
            return BS;
        }
        public DataTable HDR(List<ExcelModel> datasource)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 

            var col_ = 2;
            int colCnt = 0;
            DataTable HDR= new DataTable();
            HDR.Columns.Add("Description");
            string columns="";
            string month="";
            
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {
                month = GetPeriod(item.Pd);
                columns=columns +","+string.Format("{0} {1}", month, item.Yr);
                HDR.Columns.Add(string.Format("{0} {1}", month, item.Yr));
                col_++;
                colCnt += 1;
                
            }
            int r = 0;
            HDR.Rows.Add();
            foreach(DataColumn Column in HDR.Columns)
            {
                
                HDR.Rows[0][Column.ToString()] = Column;
            }


            string[] COlumn = columns.Split(',');

            return HDR;
        }
        private string IndexToColumn(int index)
        {
            int ColumnBase = 26;
            int DigitMax = 7; // ceil(log26(Int32.Max))
            string Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            if (index <= 0)
                throw new IndexOutOfRangeException("index must be a positive number");

            if (index <= ColumnBase)
                return Digits[index - 1].ToString();

            var sb = new StringBuilder().Append(' ', DigitMax);
            var current = index;
            var offset = DigitMax;
            while (current > 0)
            {
                sb[--offset] = Digits[--current % ColumnBase];
                current /= ColumnBase;
            }
            return sb.ToString(offset, DigitMax - offset);
        }
        private void BSrow_column_(Excel.Worksheet ws, int r, int c, string BegFormula, int col_, int c2,string BGColor_,string BGColor2)
        {
            string Column = IndexToColumn(c + 1);
            string Column2 = IndexToColumn(c2);
            ws.Cells[r, c + 1].Formula = BegFormula.Replace('G', Convert.ToChar(Column)); 
            ws.Cells[r, col_].Value = "";
            ws.Cells[r, c2].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2d;
            ws.Cells[r, c2].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
            ws.Cells[r, c2].Style.Font.Bold = true;
            ws.Cells[r, c + 1].Numberformat = "#,##0.00";
            ws.Cells[r, c2].Columns.Interior.Color=BGColor2;
            
        }
        private void row_column_(Excel.Worksheet ws, int r, int c, string BegFormula, int col_)
        {
            string Column = IndexToColumn(c + 1);

            ws.Cells[r, c + 1].Formula = BegFormula.Replace('B', Convert.ToChar(Column)); ws.Cells[r, col_].Value = "";
            ws.Cells[r, c].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2d;
            ws.Cells[r, c].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
            ws.Cells[r, c+1].Numberformat = "#,##0.00";
            ws.Cells[r, c].Style.Font.Bold = true;
        }
        private void BSrow_column(ExcelWorksheet ws, int r, int c, string BegFormula, int col_, int c2, string BGColor_, string BGColor2)
        {
            string Column = IndexToColumn(c + 1);
            string Column2 = IndexToColumn(c2);
            ws.Cells[r, c + 1].Formula = BegFormula.Replace('G', Convert.ToChar(Column));
            ws.Cells[r, col_].Value = "";
            ws.Cells[r, c2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
            ws.Cells[r, c2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            ws.Cells[r, c2].Style.Font.Bold = true;
            ws.Cells[r, c + 1].Style.Numberformat.Format = "#,##0.00";
            ws.Cells[r, c2].Style.Fill.PatternType = ExcelFillStyle.Solid;
            //ws.Cells[r, c2].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(BGColor_));
            ws.Cells[r, c2].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(BGColor2));

        }
        private void _row_column(ExcelWorksheet ws, int r, int c, string BegFormula, int col_, List<string> Yrs_)
        {
            string Column = IndexToColumn(c + 1);
            if (Yrs_[c].ToString() == "")
            {
                ws.Cells[r, c + 1].Formula = BegFormula.Replace('B', Convert.ToChar(Column)); ws.Cells[r, col_].Value = "";
                ws.Cells[r, c].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c + 1].Style.Numberformat.Format = "#,##0.00";
                ws.Cells[r, c].Style.Font.Bold = true;
            }
            else
            {
                ws.Cells[r, c + 1].Formula = BegFormula.Replace('B', Convert.ToChar(Column)); ws.Cells[r, col_].Value = "";
                ws.Cells[r, c].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c].Style.Numberformat.Format = "#,##0.00";
                ws.Cells[r, c].Style.Font.Bold = true;
            }
        }
        private void row_column(ExcelWorksheet ws, int r, int c, string BegFormula, int col_)
        {
            string Column = IndexToColumn(c + 1);
            
                ws.Cells[r, c + 1].Formula = BegFormula.Replace('B', Convert.ToChar(Column)); ws.Cells[r, col_].Value = "";
                ws.Cells[r, c].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                ws.Cells[r, c + 1].Style.Numberformat.Format = "#,##0.00";
                ws.Cells[r, c].Style.Font.Bold = true;
            
        }
        private string GetPeriod(int Pd)
        {
            string month = "";

            if (Pd == 1) { month = "Jan -"; }
            else if (Pd == 2) { month = "Feb -"; }
            else if (Pd == 3) { month = "Mar -"; }
            else if (Pd == 4) { month = "Apr -"; }
            else if (Pd == 5) { month = "May -"; }
            else if (Pd == 6) { month = "Jun -"; }
            else if (Pd == 7) { month = "Jul -"; }
            else if (Pd == 8) { month = "Aug -"; }
            else if (Pd == 9) { month = "Sep -"; }
            else if (Pd == 10) { month = "Oct -"; }
            else if (Pd == 11) { month = "Nov -"; }
            else if (Pd == 12) { month = "Dec -"; }

            return month;
        }

        private void Snapshot(ExcelPackage pck, List<SS> datasource, List<SS> datasource2)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
            ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Snapshot");

            ws.Cells[2, 1].Value = "SNAPSHOT";

            ws.Cells[1, 1].Formula = "=+IS!A1";
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[2, 1].Style.Font.Bold = true;

            ws.Cells[5, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            ws.Cells[5, 1].Value = "DESCRIPTION";
            ws.Cells[5, 1].Style.Font.Bold = true;
            var col_ = 2;
            int colCnt = 1;
            List<string> Yrs = new List<string>();
            int ic = 0;


            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                        string month = GetPeriod(item.Pd);
                        ws.Cells[5, col_].Value = string.Format("{0} {1}", month, item.Yr);
                        ws.Cells[5, col_].Style.Font.Bold = true;
                        ws.Cells[5, col_].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        ws.Cells[5, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                        col_++;
                colCnt += 1;
            }

            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource2.OrderBy(x => x.RowNo))
            {
                string IC = "";
                string FC = "";
                if (item.DescripFC == "16711680") { FC = "#1c05f3"; }
                else if (item.DescripFC == "10092543") { FC = "#f4ec9e"; }
                else { FC = item.DescripFC; }

                if (item.DescripBG == "16711680") { IC = "#1c05f3"; }
                else if (item.DescripBG == "10092543") { IC = "#f4ec9e"; }
                else { IC = item.DescripBG; }

                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC));
                ws.Cells[item.RowNo, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                ws.Cells[item.RowNo, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                using (ExcelRange Rng = ws.Cells[item.RowNo, 1, item.RowNo, 1])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC));
                }


                for (int i = 1; i <= col_ - 2; i++)
                {
                         string Column = IndexToColumn(i + 1);
                            string Column2 = IndexToColumn(i);
                            string rep = "";
                            string BS_SS = "";
                            string rep2 = "";
                            if (item.ColBot.Contains("Balance Sheet"))
                            {
                                rep = item.ColBot.Replace("Balance Sheet", "#"); BS_SS = "Balance Sheet";
                                rep2 = rep.Replace("B", Column.ToString());
                                rep2 = rep2.Replace("#", BS_SS);
                            }
                            else if (item.ColBot.Contains("IS"))
                            {
                                rep = item.ColBot.Replace("IS", "#"); BS_SS = "IS";
                                rep2 = rep.Replace("B", Column.ToString());
                                rep2 = rep2.Replace("#", BS_SS);
                            }
                            else if (item.ColBot.Contains("Snapshot"))
                            {
                                rep = item.ColBot.Replace("Snapshot", "#"); BS_SS = "Snapshot";
                                rep2 = rep.Replace("B", Column.ToString());
                                rep2 = rep2.Replace("#", BS_SS);
                            }
                            else
                            {
                                rep2 = item.ColBot.Replace("B", Column.ToString());
                                rep2 = rep2;
                            }

                            ws.Cells[item.RowNo, i + 1].Formula = rep2;
                            //ws.Cells[item.RowNo, col_].Value = "";
                            ws.Cells[item.RowNo, i + 1].Style.Numberformat.Format = "#,##0.00";
                            string IC2 = "";
                            string FC2 = "";
                            if (item.DescripFC == "16711680") { FC2 = "#1c05f3"; }
                            else if (item.DescripFC == "10092543") { FC2 = "#f4ec9e"; }
                            else { FC2 = item.ColFC; }

                            if (item.DescripBG == "16711680") { IC2 = "#1c05f3"; }
                            else if (item.DescripBG == "10092543") { IC2 = "#f4ec9e"; }
                            else { IC2 = item.ColBG; }
                            ws.Cells[item.RowNo, i + 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC2));

                            using (ExcelRange Rng = ws.Cells[item.RowNo, i + 1, item.RowNo, col_-1])
                            {
                                Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                                Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC2));
                                Rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                                Rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            }
                }

                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }

            col = 2;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {
                string IC = "";
                string FC = "";
                if (item.DescripFC == "16711680") { FC = "#1c05f3"; }
                else if (item.DescripFC == "10092543") { FC = "#f4ec9e"; }
                else { FC = item.DescripFC; }

                if (item.DescripBG == "16711680") { IC = "#1c05f3"; }
                else if (item.DescripBG == "10092543") { IC = "#f4ec9e"; }
                else { IC = item.DescripBG; }

                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC));

                using (ExcelRange Rng = ws.Cells[item.RowNo, 1, item.RowNo, 1])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC));
                }
                for (int i = 1; i <= col_ - 1; i++)
                {


                    foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                    {

                        ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.SS_DocEntry == item.SS_DocEntry).Select(x => Convert.ToDecimal(x.TotalAmount)).DefaultIfEmpty().SingleOrDefault();
                        ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";

                        string I_C = "";
                        string F_C = "";
                        if (item.DescripFC == "16711680") { F_C = "#1c05f3"; }
                        else if (item.DescripFC == "10092543") { F_C = "#f4ec9e"; }
                        else { FC = item.DescripFC; }

                        if (item.DescripBG == "16711680") { I_C = "#1c05f3"; }
                        else if (item.DescripBG == "10092543") { I_C = "#f4ec9e"; }
                        else { I_C = item.DescripBG; }

                        ws.Cells[item.RowNo, i + 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(F_C));

                        using (ExcelRange Rng = ws.Cells[item.RowNo, i , item.RowNo, col_-1])
                        {
                            Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(I_C));
                        }
                        col++;
                    }
                    col = 2;


                }
                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }
            using (ExcelRange Rng = ws.Cells[1, 1, rowCnt, 1])
            {
                Rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            }
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
            ws.View.FreezePanes(6, 1);



        }
        private void _Snapshot(ExcelPackage pck, List<SS> datasource, List<SS> datasource2)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
            ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Snapshot");

            ws.Cells[2, 1].Value = "SNAPSHOT";

            ws.Cells[1, 1].Formula = "=+IS!A1";
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[2, 1].Style.Font.Bold = true;

            ws.Cells[5, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            ws.Cells[5, 1].Value = "DESCRIPTION";
            ws.Cells[5, 1].Style.Font.Bold = true;
            var col_ = 2;
            int colCnt = 1;
           List<string> Yrs = new List<string>();
            int ic = 0;
            foreach (var item in datasource.Select(x => new { x.Yr }).Distinct())
            {
                Yrs.Add(item.Yr.ToString());
                 Yrs.Add("Space-"+item.Yr.ToString());
            }

            List<string> Yrs_ = new List<string>();
            Yrs_.Add("");
            
            foreach (string yr_ in Yrs.ToList())
            {
                if (yr_.Contains("Space"))
                {
                    col_++; Yrs_.Add("SPACE");
                    ws.Cells[5, col_-1].Value = yr_.Replace("Space-", "");
                    ws.Cells[5, col_-1].Style.Font.Bold = true;
                    ws.Cells[5, col_ - 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                }
                else
                {
                       
                        foreach (var item in datasource.Select(x => new { x.Pd}).Distinct())
                        {
                            Yrs_.Add("");
                                    string month = GetPeriod(item.Pd);
                                    ws.Cells[5, col_].Value = string.Format("{0} {1}", month, yr_.Substring(2, 2));
                                    ws.Cells[5, col_].Style.Font.Bold = true;
                                    ws.Cells[5, col_].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                                    ws.Cells[5, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                                    col_++; 
                  
                
                
                            colCnt += 1;
                        }
                }
            }
            Yrs_.Add("");
            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource2.OrderBy(x => x.RowNo))
            {
                string IC = "";
                string FC = "";
                if (item.DescripFC == "16711680") { FC = "#1c05f3"; }
                else if (item.DescripFC == "10092543") { FC = "#f4ec9e"; }
                else { FC = item.DescripFC; }

                if (item.DescripBG == "16711680") { IC = "#1c05f3"; }
                else if (item.DescripBG == "10092543") { IC = "#f4ec9e"; }
                else { IC = item.DescripBG; }

                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC));
                ws.Cells[item.RowNo, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                ws.Cells[item.RowNo, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                using (ExcelRange Rng = ws.Cells[item.RowNo, 1, item.RowNo, 1])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC));
                }


                for (int i = 1; i <= col_ - 1; i++)
                {
                    string Column = IndexToColumn(i + 1);
                    string Column2 = IndexToColumn(i);
                    string rep = "";
                    string BS_SS = "";
                    string rep2 = "";
                    if (item.ColBot.Contains("Balance Sheet"))
                    {
                        rep = item.ColBot.Replace("Balance Sheet", "#"); BS_SS = "Balance Sheet";
                        rep2 = rep.Replace("B", Column.ToString());
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else if (item.ColBot.Contains("IS"))
                    {
                        rep = item.ColBot.Replace("IS", "#"); BS_SS = "IS";
                        rep2 = rep.Replace("B", Column.ToString());
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else if (item.ColBot.Contains("Snapshot"))
                    {
                        rep = item.ColBot.Replace("Snapshot", "#"); BS_SS = "Snapshot";
                        rep2 = rep.Replace("B", Column.ToString());
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else
                    {
                        rep2 = item.ColBot.Replace("B", Column.ToString());
                        rep2 = rep2;
                    }
                    if (Yrs_[i].ToString() == "")
                    {
                       
                        ws.Cells[item.RowNo, i + 1].Formula = rep2;
                        ws.Cells[item.RowNo, col_].Value = "";
                        ws.Cells[item.RowNo, i + 1].Style.Numberformat.Format = "#,##0.00";
                        string IC2 = "";
                        string FC2 = "";
                        if (item.DescripFC == "16711680") { FC2 = "#1c05f3"; }
                        else if (item.DescripFC == "10092543") { FC2 = "#f4ec9e"; }
                        else { FC2 = item.ColFC; }

                        if (item.DescripBG == "16711680") { IC2 = "#1c05f3"; }
                        else if (item.DescripBG == "10092543") { IC2 = "#f4ec9e"; }
                        else { IC2 = item.ColBG; }
                        ws.Cells[item.RowNo, i + 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC2));

                        using (ExcelRange Rng = ws.Cells[item.RowNo, i + 1, item.RowNo, col_])
                        {
                            Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC2));
                            Rng.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            Rng.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        }
                    }
                    else
                    {
                        ws.Cells[item.RowNo, i + 1].Formula = rep2;
                        ws.Cells[item.RowNo, i+1].Style.Font.Bold= true;
                        ws.Cells[item.RowNo, i + 1].Style.Numberformat.Format = "#,##0.00";
                    }
                    }
                    
                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }

             col = 2;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {
                string IC = "";
                string FC = "";
                if (item.DescripFC == "16711680") { FC = "#1c05f3"; }
                else if (item.DescripFC == "10092543") { FC = "#f4ec9e"; }
                else { FC = item.DescripFC; }

                if (item.DescripBG == "16711680") { IC = "#1c05f3"; }
                else if (item.DescripBG == "10092543") { IC = "#f4ec9e"; } 
                else { IC = item.DescripBG; }

                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(FC));

                using (ExcelRange Rng = ws.Cells[item.RowNo, 1, item.RowNo, 1])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(IC));
                }
                for (int i = 1; i <= col_ - 1; i++)
                {

                    decimal Tot=0;
                    foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                    {

                        if (Yrs_[col-1].ToString() == "")
                        {
                            ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.SS_DocEntry == item.SS_DocEntry).Select(x => Convert.ToDecimal(x.TotalAmount)).DefaultIfEmpty().SingleOrDefault();
                            ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";

                            string I_C = "";
                            string F_C = "";
                            if (item.DescripFC == "16711680") { F_C = "#1c05f3"; }
                            else if (item.DescripFC == "10092543") { F_C = "#f4ec9e"; }
                            else { FC = item.DescripFC; }

                            if (item.DescripBG == "16711680") { I_C = "#1c05f3"; }
                            else if (item.DescripBG == "10092543") { I_C = "#f4ec9e"; }
                            else { I_C = item.DescripBG; }

                            ws.Cells[item.RowNo, i + 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(F_C));

                            using (ExcelRange Rng = ws.Cells[item.RowNo, i + 1, item.RowNo, col_])
                            {
                                Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                                Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(I_C));
                            }
                            if (ws.Cells[item.RowNo, col].Value == null) { Tot += 0; }
                            else if (ws.Cells[item.RowNo, col].Value == "") { Tot += 0; }
                            else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot += 0; }
                            else { Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                            col++;
                        }
                        else {

                            ws.Cells[item.RowNo, col].Value = Tot;
                            ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                            ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                            Tot = 0;
                            col++;
                        ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.SS_DocEntry == item.SS_DocEntry).Select(x => Convert.ToDecimal(x.TotalAmount)).DefaultIfEmpty().SingleOrDefault();
                        if (ws.Cells[item.RowNo, col].Value == null) { Tot += 0; }
                        else if (ws.Cells[item.RowNo, col].Value == "") { Tot += 0; }
                        else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot += 0; }
                        else { Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                        ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00"; col++;
                        }

                        
                    }
                    ws.Cells[item.RowNo, col].Value = Tot;
                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                    ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                    col = 2;
                   

                }
                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }
            using (ExcelRange Rng = ws.Cells[1, 1, rowCnt, 1])
            {
                Rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            }
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
            ws.View.FreezePanes(6, 1);

           

        }


        private void _IncomeStatement(ExcelPackage pck, List<IS> datasource)
        {


            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
            ExcelWorksheet ws = pck.Workbook.Worksheets.Add("IS");

            ws.Cells[3, 1].Value = "INCOME STATEMENT";

            ws.Cells[1, 1].Value = datasource[0].Blk;
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[3, 1].Style.Font.Bold = true;

            ws.Cells[6, 1].Value = "ACCOUNT TITLE";
            ws.Cells[6, 1].Style.Font.Bold = true;
            ws.Cells[6, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            int col_ = 2;
            int colCnt = 1;
            List<string> Yrs = new List<string>();
            int ic = 0;
            foreach (var item in datasource.Select(x => new { x.Yr }).Distinct())
            {
                Yrs.Add(item.Yr.ToString());
                Yrs.Add("Space-"+item.Yr.ToString());
            }
            List<string> Yrs_ = new List<string>();
            int addColum = Yrs.Count / 2;
            Yrs_.Add("");

            foreach (string yr_ in Yrs.ToList())
            {
                if (yr_.Contains("Space")) { col_++; Yrs_.Add("SPACE");
                ws.Cells[6, col_-1].Value =  yr_.Replace("Space-","");
                ws.Cells[6, col_-1].Style.Font.Bold = true;
                ws.Cells[6, col_ - 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                }
                else
                {
                    foreach (var item in datasource.Select(x => new { x.Pd}).Distinct())
                    {
                        Yrs_.Add("");
                        string month = GetPeriod(item.Pd);
                        ws.Cells[6, col_].Value = string.Format("{0} {1}", month, yr_.Substring(2,2));
                        ws.Cells[6, col_].Style.Font.Bold = true;
                        ws.Cells[6, col_].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        ws.Cells[6, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                        col_++;
                        colCnt += 1;
                    }
                }
            }
            Yrs_.Add("");
            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {
                ws.Cells[item.RowNo, 1].Value = item.Dscpt;
                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }

                for (int i = 1; i <= col_ - 1; i++)
                {

                    if (item.Dscpt.Trim() == "NET SALES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }

                    else if (item.Dscpt.Trim() == "TOTAL COST OF SERVICE")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "GROSS PROFIT FROM SERVICES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL OPERATING EXPENSES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME LESS OPERATING EXPENSES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL OTHER INCOME/(EXPENSES)" || item.Dscpt.Trim() == "TOTAL OTHER EXPENSES/INCOME" || item.Dscpt.Trim() == "TOTAL OTHER INCOME/EXPENSES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/(LOSS)" || item.Dscpt.Trim() == "NET INCOME/LOSS")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL EXPENSES FROM OA")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL INCOME FROM OA:" || item.Dscpt.Trim() == "TOTAL INCOME FROM OA")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/LOSS (INCLUDING OA)")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/LOSS:" || item.Dscpt.Trim() == "NET INCOME/LOSS")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL ASSET PURCHASES")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:")
                    {
                        _row_column(ws, item.RowNo, i, item.BegFormula, col_, Yrs_);
                    }
                    else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:")
                    {

                        _row_column(ws, item.RowNo, i, item.BegFormula, col_,Yrs_);
                    }
                    else if (item.Hrd == "H")
                    {
                        if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                        else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                        if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                        else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }
                    }
                    else if (item.DscrptTop == "1" || item.DscrptBot == "1")
                    {
                        if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                        else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                        if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                        else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }
                        if (item.total != "" || item.total != null)
                        {
                            decimal Tot = 0;
                            foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                            {

                                if (Yrs_[col - 1].ToString() == "")
                                {

                                    ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                    ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                                    //Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value);
                                    if (ws.Cells[item.RowNo, col].Value == null) { Tot += 0; }
                                    else if (ws.Cells[item.RowNo, col].Value == "") { Tot += 0; }
                                    else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot += 0; }
                                    else { Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                                    col++;
                                }
                                else
                                {
                                    ws.Cells[item.RowNo, col].Value = Tot;
                                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                    ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                                    Tot = 0;
                                    col++;
                                    ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                    if (ws.Cells[item.RowNo, col].Value == null) { Tot = 0; }
                                    else if (ws.Cells[item.RowNo, col].Value == "") { Tot = 0; }
                                    else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot = 0; }
                                    else { Tot = Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                                    col++;

                                }


                            }
                            ws.Cells[item.RowNo, col].Value = Tot;
                            ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                            ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                            col = 2;
                        }
                    }
                    else
                    {
                        decimal Tot = 0;
                        foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                        {
                           
                            if (Yrs_[col - 1].ToString() == "")
                            {
                                
                                ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                //Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value);
                                if (ws.Cells[item.RowNo, col].Value == null) { Tot += 0; }
                                else if (ws.Cells[item.RowNo, col].Value == "") { Tot += 0; }
                                else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot += 0; }
                                else { Tot += Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                                col++;
                            }
                            else
                            {
                                ws.Cells[item.RowNo, col].Value = Tot;
                                ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                                Tot = 0;
                                col++;
                                ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                if (ws.Cells[item.RowNo, col].Value == null) { Tot = 0; }
                                else if (ws.Cells[item.RowNo, col].Value == "") { Tot = 0; }
                                else if (ws.Cells[item.RowNo, col].Value == DBNull.Value) { Tot = 0; }
                                else { Tot = Convert.ToDecimal(ws.Cells[item.RowNo, col].Value); }
                                col++;

                            }


                        }
                        ws.Cells[item.RowNo, col].Value = Tot;
                        ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                        ws.Cells[item.RowNo, col].Style.Font.Bold = true;
                        col = 2;
                    }
                }







                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }





            }
            for (int i = 1; i <= colCnt; i++)
            {
                ws.Cells[rowCnt, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            }

            using (ExcelRange Rng = ws.Cells[6, 1, rowCnt, colCnt + addColum])
            {
                Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                //Rng.Style.Fill.BackgroundColor.SetColor(Color.LightYellow);
                Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml("#ffffaf"));
            }
            using (ExcelRange Rng = ws.Cells[6, 1, rowCnt, 2])
            {
                Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                //Rng.Style.Fill.BackgroundColor.SetColor(Color.LightYellow);
                Rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                Rng.Style.Border.Left.Color.SetColor(Color.Black);



            }
            using (ExcelRange Rng = ws.Cells[1, 1, rowCnt, 1])
            {
                Rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            }
            ws.Cells[ws.Dimension.Address].AutoFitColumns();
            ws.View.FreezePanes(7, 1);



        }
       
        private void Snapshot_(Excel.Worksheet ws, List<SS> datasource, List<SS> datasource2)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
         
            //ws.Name = "Snapshot";

            ws.Cells[2, 1].Value = "SNAPSHOT";

            ws.Cells[1, 1].Value  = "=+IS!A1";
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[2, 1].Style.Font.Bold = true;

            ws.Cells[5, 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
            ws.Cells[5, 1].Value = "DESCRIPTION";
            ws.Cells[5, 1].Style.Font.Bold = true;
            var col_ = 2;
            int colCnt = 1;
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                string month = GetPeriod(item.Pd);
                ws.Cells[5, col_].Value = string.Format("{0} {1}", month, item.Yr);
                ws.Cells[5, col_].Font.Bold = true;
                ws.Cells[5, col_].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
                
                col_++;
                colCnt += 1;
            }

            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource2.OrderBy(x => x.RowNo))
            {
                string DESC_BG = "";
                string DESC_FC = "";
                string VAL_BG = "";
                string VAL_FC = "";
                 if (item.Descrip == "CASH") 
                 { DESC_BG = "0"; } 
                if (item.DescripBG == "") { DESC_BG = "0"; } else { DESC_BG = item.DescripBG; }
                if (item.DescripFC == "") { DESC_FC = "0"; } else { DESC_FC = item.DescripFC; }
                if (item.ColBG == "") { VAL_BG = DESC_BG; } else { VAL_BG = item.ColBG; }
                if (item.ColFC == "") { VAL_FC = "0"; } else { VAL_FC = item.ColFC; }


                
                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                //ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Columns.Interior.Color = DESC_BG;
                ws.Cells[item.RowNo, 1].Columns.Font.Color = DESC_FC;
                
                for (int i = 1; i <= col_ - 1; i++)
                {

                    string Column = IndexToColumn(i + 1);
                    string Column2 = IndexToColumn(i);
                    string rep = "";
                    string BS_SS = "";
                    string rep2 = "";
                    if (item.ColBot.Contains("Balance Sheet"))
                    {
                        rep = item.ColBot.Replace("Balance Sheet", "#"); BS_SS = "Balance Sheet";
                        rep2 = rep.Replace('B', Convert.ToChar(Column));
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else if (item.ColBot.Contains("IS"))
                    {
                        rep = item.ColBot.Replace("IS", "#"); BS_SS = "IS";
                        rep2 = rep.Replace('B', Convert.ToChar(Column));
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else if (item.ColBot.Contains("Snapshot"))
                    {
                        rep = item.ColBot.Replace("Snapshot", "#"); BS_SS = "Snapshot";
                        rep2 = rep.Replace('B', Convert.ToChar(Column));
                        rep2 = rep2.Replace("#", BS_SS);
                    }
                    else
                    {
                        rep2 = item.ColBot.Replace('B', Convert.ToChar(Column));
                        rep2 = rep2;
                    }

                    ws.Cells[item.RowNo, i + 1].Value = rep2;
                    ws.Cells[item.RowNo, col_].Value = "";
                    ws.Cells[item.RowNo, i + 1].Numberformat = "#,##0.00";
                    ws.Cells[item.RowNo, i].Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = 2d;
                    ws.Cells[item.RowNo, i].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
                    ws.Cells[item.RowNo, i ].Columns.Interior.Color = VAL_BG;
                    ws.Cells[item.RowNo, i + 1].Columns.Font.Color = VAL_FC;
                }



                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }

            col = 2;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {

                string DESC_BG = "";
                string DESC_FC = "";
                string VAL_BG = "";
                string VAL_FC = "";

                if (item.DescripBG == "") { DESC_BG = "0"; } else { DESC_BG = item.DescripBG; }
                if (item.DescripFC == "") { DESC_FC = "0"; } else { DESC_FC = item.DescripFC; }
                if (item.ColBG == "") { VAL_BG = "0"; } else { VAL_BG = item.ColBG; }
                if (item.ColFC == "") { VAL_FC = "0"; } else { VAL_FC = item.ColFC; }

                ws.Cells[item.RowNo, 1].Value = item.Descrip;
                //ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                ws.Cells[item.RowNo, 1].Columns.Interior.Color = DESC_BG;
                ws.Cells[item.RowNo, 1].Columns.Font.Color = DESC_FC;
               
                for (int i = 1; i <= col_ - 1; i++)
                {


                    foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                    {

                        ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.SS_DocEntry == item.SS_DocEntry).Select(x => Convert.ToDecimal(x.TotalAmount)).DefaultIfEmpty().SingleOrDefault();
                        ws.Cells[item.RowNo, col].Numberformat = "#,##0.00";
                        ws.Cells[item.RowNo, i].Font.Bold=false;
                        ws.Cells[item.RowNo, i].Columns.Interior.Color = VAL_BG;
                        ws.Cells[item.RowNo, i+1].Columns.Font.Color = VAL_FC;
                       

                        col++;
                    }
                    col = 2;


                }
                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }
            ws.Range["a1", "a" + rowCnt.ToString()].Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 2d;
            //ws.Cells[ws.Dimension.Address].AutoFitColumns();
            //ws.View.FreezePanes(6, 1);



        }
        private void BalanceSheet_(Excel.Worksheet ws, List<ExcelModel> datasource)
        {
            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
          

            ws.Cells[3, 1].Value = "BALANCE SHEET";

            ws.Cells[1, 1].Value = datasource[0].Blk;
            ws.Cells[1, 1].Font.Bold = true;
            ws.Cells[3, 1].Font.Bold = true;

            ws.Cells[6, 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
            ws.Cells[6, 1].Value = "ASSET";
            ws.Cells[6, 1].Font.Bold = true;
            var col_ = 2;
            int colCnt = 1;
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {

                string month = GetPeriod(item.Pd);
                ws.Cells[6, col_].Value = string.Format("{0} {1}", month, item.Yr);
                ws.Cells[6, col_].Font.Bold = true;
                ws.Cells[6, col_].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
                col_++;
                colCnt += 1;
            }

            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {
                if (item.Dscpt == "Marketing Supplies"){ }
                ws.Cells[item.RowNo, 1].Value = item.Dscpt;
                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Font.Bold = true; }
                else { ws.Cells[item.RowNo, 1].Font.Bold = false; }
                if (item.HrdFC == "0" || item.HrdFC.Trim() == "") { ws.Cells[item.RowNo, 1].Columns.Font.Color = Color.Black; }
                else { ws.Cells[item.RowNo, 1].Columns.Font.Color=item.HrdFC; }

                for (int i = 1; i <= col_ - 1; i++)
                {
                    if (item.Dscpt.Trim() == "TOTAL CASH")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);
                    }

                    else if (item.Dscpt.Trim() == "TOTAL A/R:" || item.Dscpt.Trim() == "TOTAL A/R")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "TOTAL INVENTORY:" || item.Dscpt.Trim() == "TOTAL INVENTORY")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL OTHER ASSETS:" || item.Dscpt.Trim() == "TOTAL OTHER ASSETS")
                    {

                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "Tools & Other Equipment" || item.Dscpt.Trim() == "Tools & Other Equipment:")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "TOTAL PROPERTY & EQUIPMENT:" || item.Dscpt.Trim() == "TOTAL PROPERTY & EQUIPMENT")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);
                    }

                    else if (item.Dscpt.Trim() == "TOTAL DEPRECIATION:" || item.Dscpt.Trim() == "TOTAL DEPRECIATION:")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "Total P&E (w/ Depreciation):" || item.Dscpt.Trim() == "Total P&E (w/ Depreciation)")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                    }
                    //
                    else if (item.Dscpt.Trim() == "TOTAL ASSETS:" || item.Dscpt.Trim() == "TOTAL ASSETS")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "TOTAL ASSETS: (assume no deprec)" || item.Dscpt.Trim() == "TOTAL ASSETS: (assume no deprec)")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "TOTAL ASSETS (w/ Depreciation):" || item.Dscpt.Trim() == "TOTAL ASSETS (w/ Depreciation):")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);
                    }

                    else if (item.Dscpt.Trim() == "Total Accounts Payable:s" || item.Dscpt.Trim() == "Total Accounts Payables" || item.Dscpt.Trim() == "Total Accounts Payable")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);

                    }
                    else if (item.Dscpt.Trim() == "Total P&E (w/ Depreciation):" || item.Dscpt.Trim() == "Total P&E (w/ Depreciation):")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                    }
                    else if (item.Dscpt.Trim() == "Total P&E (w/depreciation)" || item.Dscpt.Trim() == "Total P&E (w/depreciation):")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                    }
                    else if (item.Dscpt.Trim() == "Total Current Assets" || item.Dscpt.Trim() == "Total Current Assets:")
                    {
                        BSrow_column_(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                    }
                    else if (item.Hrd == "H")
                    {
                        for (int c = 1; c <= colCnt; c++) { 
                            if (item.HrdFS == "Bold")
                            {
                                ws.Cells[item.RowNo, c].Font.Bold = true;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                            else
                            {
                                ws.Cells[item.RowNo, c].Font.Bold = false;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                            if (item.HrdFC == "0")
                            {
                                ws.Cells[item.RowNo, c].Columns.Font.Color=Color.Black;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                            else
                            {
                                ws.Cells[item.RowNo, c].Columns.Font.Color=item.HrdFC;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                        }
                    }
                    else if (item.DscrptTop == "1")
                    {
                        for (int c = 0; c == colCnt; c++)
                        {
                            if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, c].Font.Bold = true; ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG; }
                            else
                            {
                                ws.Cells[item.RowNo, c].Font.Bold = false;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                            if (item.HrdFC == "0") { ws.Cells[item.RowNo, c].Columns.Font.Color = Color.Black; ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG; }
                            else
                            {
                                ws.Cells[item.RowNo, c].Columns.Font.Color = item.HrdFC;
                                ws.Cells[item.RowNo, c].Columns.Interior.Color = item.DscrptBG;
                            }
                        }
                    }
                    else if (item.DscrptTop == "1" && item.DscrptBot == "1")
                    {
                        ws.Cells[item.RowNo, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                        if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Font.Bold = true; ws.Cells[item.RowNo, 1].Columns.Interior.Color = item.DscrptBG; }
                        else
                        {
                            ws.Cells[item.RowNo, 1].Font.Bold = false;
                            ws.Cells[item.RowNo, 1].Columns.Interior.Color = item.DscrptBG;
                        }
                        if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Columns.Font.Color=Color.Black; ws.Cells[item.RowNo, 1].Columns.Interior.Color = item.DscrptBG; }
                        else
                        {
                            ws.Cells[item.RowNo, 1].Columns.Font.Color=item.HrdFC;
                            ws.Cells[item.RowNo, 1].Columns.Interior.Color = item.DscrptBG;
                        }
                    }
                    else
                    {
                        foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                        {

                            ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                            ws.Cells[item.RowNo, col].Font.Bold = false;
                            ws.Cells[item.RowNo, col-1].Columns.Interior.Color = item.DscrptBG;
                            ws.Cells[item.RowNo, col].Columns.Interior.Color=item.DscrptBG;
                            ws.Cells[item.RowNo, col].Numberformat = "#,##0.00";
                            col++;
                        }
                        col = 2;
                    }

                }
                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }
            ws.Range["a1", "a" + rowCnt.ToString()].Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 2d;



        }

        private void IncomeStatement_(Excel.Worksheet ws, List<IS> datasource)
        {


            double maximumSize = 50;
            double minimumSize = 10;

            var row1 = datasource[0];
            //Create the worksheet 
            

            ws.Cells[3, 1].Value = "INCOME STATEMENT";
            ws.Cells[1, 1].Value = datasource[0].Blk;
            ws.Cells[1, 1].Font.Bold = true;
            ws.Cells[3, 1].Font.Bold = true;
            ws.Cells[6, 1].Value = "ACCOUNT TITLE";
            ws.Cells[6, 1].Font.Bold = true;
            ws.Cells[6, 1].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
            int col_ = 2;
            int colCnt = 1;
            foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
            {
                string month = GetPeriod(item.Pd);

                ws.Cells[6, col_].Value = string.Format("{0} {1}", month, item.Yr);
                ws.Cells[6, col_].Font.Bold = true;

                ws.Cells[6, col_].Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = 2d;
                //ws.Cells[6, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                col_++;
                colCnt += 1;

            }

            int col = 2;
            int rowCnt = 0;
            foreach (var item in datasource.OrderBy(x => x.RowNo))
            {
                ws.Cells[item.RowNo, 1].Value = item.Dscpt;
                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Font.Bold = true; }
                else { ws.Cells[item.RowNo, 1].Font.Bold = false; }
                if (item.HrdFC == "0" || item.HrdFC.Trim() == "") { ws.Cells[item.RowNo, 1].Columns.Font.Color = Color.Black; }
                else { ws.Cells[item.RowNo, 1].Columns.Interior.Color=item.HrdFC; }

                for (int i = 1; i <= col_ - 1; i++)
                {


                    if (item.Dscpt.Trim() == "NET SALES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }

                    else if (item.Dscpt.Trim() == "TOTAL COST OF SERVICE")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "GROSS PROFIT FROM SERVICES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL OPERATING EXPENSES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME LESS OPERATING EXPENSES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL OTHER INCOME/(EXPENSES)" || item.Dscpt.Trim() == "TOTAL OTHER EXPENSES/INCOME" || item.Dscpt.Trim() == "TOTAL OTHER INCOME/EXPENSES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/(LOSS)" || item.Dscpt.Trim() == "NET INCOME/LOSS")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL EXPENSES FROM OA")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL INCOME FROM OA:" || item.Dscpt.Trim() == "TOTAL INCOME FROM OA")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/LOSS (INCLUDING OA)")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "NET INCOME/LOSS:" || item.Dscpt.Trim() == "NET INCOME/LOSS")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "TOTAL ASSET PURCHASES")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:")
                    {
                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:")
                    {

                        row_column_(ws, item.RowNo, i, item.BegFormula, col_);
                    }
                    else if (item.Hrd == "H")
                    {
                        if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Font.Bold = true; }
                        else { ws.Cells[item.RowNo, 1].Font.Bold = false; }
                        if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Columns.Font.Color=Color.Black; }
                        else { ws.Cells[item.RowNo, 1].Columns.Font.Color=item.HrdFC; }
                    }
                    else if (item.DscrptTop == "1" || item.DscrptBot == "1")
                    {
                        if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Font.Bold = true; }
                        else { ws.Cells[item.RowNo, 1].Font.Bold = false; }
                        if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Columns.Font.Color=Color.Black; }
                        else { ws.Cells[item.RowNo, 1].Columns.Font.Color=item.HrdFC; }
                        if (item.total != "" || item.total != null) {
                            foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                            {
                                ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                ws.Cells[item.RowNo, col].Font.Bold = false;
                                ws.Cells[item.RowNo, col].Numberformat = "#,##0.00";
                                col++;

                            }
                            col = 2;
                        }
                    }
                    else
                    {
                        foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                        {
                            ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                            ws.Cells[item.RowNo, col].Font.Bold = false; 
                            ws.Cells[item.RowNo, col].Numberformat = "#,##0.00";
                            col++;

                        }
                        col = 2;
                    }
                }



                if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
            }

            string LAst = IndexToColumn(colCnt);

            ws.Range["A6", "" + LAst + "" + rowCnt.ToString()].Interior.Color = "10092543";
            ws.Range["a1", "a" + rowCnt.ToString()].Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = 2d;
            //for (int r = 1; r <= rowCnt; r++)
            //{
            //    for (int c = 1; r <= colCnt; c++)
            //    {
            //        ws.Cells[r, c].Columns.Interior.Color = "10092543";
            //        ws.Cells[item.RowNo, 1].Columns.Interior.Color = item.HrdFC;
            //    }
            //}
            //for (int i = 1; i <= colCnt; i++)
            //{
            //    ws.Cells[rowCnt, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            //}

          
            //ws.Cells[ws.Dimension.Address].AutoFitColumns();
            //ws.View.FreezePanes(7, 1);


        }
        private void BalanceSheet(ExcelPackage pck, List<ExcelModel> datasource)
        {
                double maximumSize = 50;
                double minimumSize = 10;
            
                var row1 = datasource[0];
                //Create the worksheet 
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Balance Sheet");

                ws.Cells[3, 1].Value = "BALANCE SHEET";
              
                ws.Cells[1, 1].Value = datasource[0].Blk;
                ws.Cells[1, 1].Style.Font.Bold=true;
                ws.Cells[3, 1].Style.Font.Bold = true;
               
                ws.Cells[6, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                ws.Cells[6, 1].Value = "ASSET";
                ws.Cells[6, 1].Style.Font.Bold = true;
                var col_ = 2;
                int colCnt = 1;
                foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                {

                    string month = GetPeriod(item.Pd);
                    ws.Cells[6, col_].Value = string.Format("{0} {1}", month, item.Yr);
                    ws.Cells[6, col_].Style.Font.Bold = true;
                    ws.Cells[6, col_].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    ws.Cells[6, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                    col_++;
                    colCnt += 1;
                }

                int col = 2;
                int rowCnt = 0;
                foreach (var item in datasource.OrderBy(x => x.RowNo))
                {
                    if (item.Dscpt == "Marketing Supplies")
                    {

                    }
                    ws.Cells[item.RowNo, 1].Value = item.Dscpt;
                    if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                    else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                    if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                    else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }

                    using (ExcelRange Rng = ws.Cells[item.RowNo, 1, item.RowNo, colCnt])
                    {
                        Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                    } 

                    
                        for (int i = 1; i <= col_ - 1; i++)
                        {

                            if (item.Dscpt.Trim() == "TOTAL CASH")
                            {
                                BSrow_column(ws, item.RowNo, i , item.BegFormula, col_, i, "#ffffaf",item.DscrptBG);
                            }

                            else if (item.Dscpt.Trim() == "TOTAL A/R:" || item.Dscpt.Trim() == "TOTAL A/R")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "TOTAL INVENTORY:" || item.Dscpt.Trim() == "TOTAL INVENTORY")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL OTHER ASSETS:" || item.Dscpt.Trim() == "TOTAL OTHER ASSETS")
                            {

                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "Tools & Other Equipment" || item.Dscpt.Trim() == "Tools & Other Equipment:")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);
                                
                            }
                            else if (item.Dscpt.Trim() == "TOTAL PROPERTY & EQUIPMENT:" || item.Dscpt.Trim() == "TOTAL PROPERTY & EQUIPMENT")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);
                            }

                            else if (item.Dscpt.Trim() == "TOTAL DEPRECIATION:" || item.Dscpt.Trim() == "TOTAL DEPRECIATION:")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "Total P&E (w/ Depreciation):" || item.Dscpt.Trim() == "Total P&E (w/ Depreciation)")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                            }
                            //
                            else if (item.Dscpt.Trim() == "TOTAL ASSETS:" || item.Dscpt.Trim() == "TOTAL ASSETS")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "TOTAL ASSETS: (assume no deprec)" || item.Dscpt.Trim() == "TOTAL ASSETS: (assume no deprec)")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#ffffaf", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "TOTAL ASSETS (w/ Depreciation):" || item.Dscpt.Trim() == "TOTAL ASSETS (w/ Depreciation):")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#bff2ba", item.DscrptBG);
                            }

                            else if (item.Dscpt.Trim() == "Total Accounts Payable:s" || item.Dscpt.Trim() == "Total Accounts Payables" || item.Dscpt.Trim() == "Total Accounts Payable")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#f891c0", item.DscrptBG);

                            }
                            else if (item.Dscpt.Trim() == "Total P&E (w/ Depreciation):" || item.Dscpt.Trim() == "Total P&E (w/ Depreciation):")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                            }
                            else if (item.Dscpt.Trim() == "Total P&E (w/depreciation)" || item.Dscpt.Trim() == "Total P&E (w/depreciation):")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                            }
                            else if (item.Dscpt.Trim() == "Total Current Assets" || item.Dscpt.Trim() == "Total Current Assets:")
                            {
                                BSrow_column(ws, item.RowNo, i, item.BegFormula, col_, i, "#a6bdff", item.DscrptBG);
                            }
                            else if (item.Hrd == "H")
                            {
                                ws.Cells[item.RowNo, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true;
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false;
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black);
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC));
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }

                            }
                            else if (item.DscrptTop == "1")
                            {
                                ws.Cells[item.RowNo, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG)); }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false;
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG)); }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC));
                                ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                            }
                            else if (item.DscrptTop == "1" && item.DscrptBot == "1")
                            {
                                ws.Cells[item.RowNo, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG)); }
                                else
                                {
                                    ws.Cells[item.RowNo, 1].Style.Font.Bold = false;
                                    ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG)); }
                                else
                                {
                                    ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC));
                                    ws.Cells[item.RowNo, 1].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                }
                            }
                            else
                            {
                                foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                                {

                                    ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                    ws.Cells[item.RowNo, col].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    ws.Cells[item.RowNo, col].Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml(item.DscrptBG));
                                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                    col++;
                                }
                                col = 2;
                            }
                           
                        }
                    if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
                }
                for (int i = 1; i <= colCnt;i++ )
                {
                    ws.Cells[rowCnt, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    ws.Cells[rowCnt + 1, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }
                using (ExcelRange Rng = ws.Cells[6, 1, rowCnt, 2])
                {
                //    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;;
                //    //Rng.Style.Fill.BackgroundColor.SetColor(Color.LightYellow);
                  Rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                //    Rng.Style.Border.Left.Color.SetColor(Color.Transparent);

                }
                using (ExcelRange Rng = ws.Cells[1, 1, rowCnt, 1])
                {
                    Rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                }
                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                ws.View.FreezePanes(7, 1);
        
            
          
        }
        private void IncomeStatement(ExcelPackage pck,List<IS> datasource)
        {
          

            double maximumSize = 50;
            double minimumSize = 10;

                var row1 = datasource[0];
                //Create the worksheet 
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("IS");

                ws.Cells[3, 1].Value = "INCOME STATEMENT";
                ws.Cells[1, 1].Value = datasource[0].Blk;
                ws.Cells[1, 1].Style.Font.Bold = true;
                ws.Cells[3, 1].Style.Font.Bold = true;
                ws.Cells[6, 1].Value = "ACCOUNT TITLE";
                ws.Cells[6, 1].Style.Font.Bold = true;
                ws.Cells[6, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                int col_ = 2;
                int colCnt = 1;
                foreach (var item in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                {
                    string month = GetPeriod(item.Pd);

                    ws.Cells[6, col_].Value = string.Format("{0} {1}", month, item.Yr);
                    ws.Cells[6, col_].Style.Font.Bold = true;

                    ws.Cells[6, col_].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    ws.Cells[6, col_].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                    col_++;
                    colCnt += 1;

                }
            
                int col = 2;
                int rowCnt = 0;
                foreach (var item in datasource.OrderBy(x => x.RowNo))
                {
                    ws.Cells[item.RowNo, 1].Value = item.Dscpt;
                    if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                    else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                    if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                    else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }
                    
                        for (int i = 1; i <= col_-1; i++)
                        {

                            if (item.Dscpt.Trim() == "NET SALES")
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }

                            else if (item.Dscpt.Trim() == "TOTAL COST OF SERVICE")
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                             }
                            else if (item.Dscpt.Trim() == "GROSS PROFIT FROM SERVICES") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL OPERATING EXPENSES") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "NET INCOME LESS OPERATING EXPENSES") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL OTHER INCOME/(EXPENSES)" || item.Dscpt.Trim() == "TOTAL OTHER EXPENSES/INCOME" || item.Dscpt.Trim() == "TOTAL OTHER INCOME/EXPENSES") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "NET INCOME/(LOSS)" || item.Dscpt.Trim() == "NET INCOME/LOSS") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL EXPENSES FROM OA")
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL INCOME FROM OA:" || item.Dscpt.Trim() == "TOTAL INCOME FROM OA") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "NET INCOME/LOSS (INCLUDING OA)") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "NET INCOME/LOSS:" || item.Dscpt.Trim() == "NET INCOME/LOSS") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "TOTAL ASSET PURCHASES") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:") 
                            {
                                row_column(ws, item.RowNo, i, item.BegFormula, col_);
                            }
                            else if (item.Dscpt.Trim() == "ADD: Direct to Main commission:") 
                            {
                                
                                row_column(ws, item.RowNo, i, item.BegFormula,col_);
                            }
                           else if (item.Hrd == "H")
                            {
                                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }
                            }
                            else if (item.DscrptTop == "1" || item.DscrptBot == "1")
                            {
                                if (item.HrdFS == "Bold") { ws.Cells[item.RowNo, 1].Style.Font.Bold = true; }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Bold = false; }
                                if (item.HrdFC == "0") { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(Color.Black); }
                                else { ws.Cells[item.RowNo, 1].Style.Font.Color.SetColor(ColorTranslator.FromHtml(item.HrdFC)); }
                            }
                            else
                            {
                                foreach (var period in datasource.Select(x => new { x.Pd, x.Yr }).Distinct())
                                {
                                    ws.Cells[item.RowNo, col].Value = datasource.Where(x => x.Pd == period.Pd && x.Yr == period.Yr && x.DocEntry == item.DocEntry).Select(x => x.total).DefaultIfEmpty().SingleOrDefault();
                                    ws.Cells[item.RowNo, col].Style.Numberformat.Format = "#,##0.00";
                                    col++;

                                }
                                col = 2;
                            }
                        }
                    
                   
                   
                    if (item.RowNo > rowCnt) { rowCnt = item.RowNo; }
                }
                for (int i = 1; i <= colCnt; i++)
                {
                    ws.Cells[rowCnt, i].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }
                
                using (ExcelRange Rng = ws.Cells[6, 1, rowCnt, colCnt])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    //Rng.Style.Fill.BackgroundColor.SetColor(Color.LightYellow);
                    Rng.Style.Fill.BackgroundColor.SetColor(ColorTranslator.FromHtml("#ffffaf"));
                }
                using (ExcelRange Rng = ws.Cells[6, 1, rowCnt, 2])
                {
                    Rng.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    //Rng.Style.Fill.BackgroundColor.SetColor(Color.LightYellow);
                    Rng.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    Rng.Style.Border.Left.Color.SetColor(Color.Black);
                    
                }
                using (ExcelRange Rng = ws.Cells[1, 1, rowCnt, 1])
                {
                    Rng.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                }
                ws.Cells[ws.Dimension.Address].AutoFitColumns();
                ws.View.FreezePanes(7, 1);
              
            
        }
    } 
}