(function () {
    'use strict';

    angular.module('app').factory('SnapshotService', Service)

    Service.$inject = ['$http', '$localStorage','toastr', 'serviceBasePath', '$httpParamSerializerJQLike', '$rootScope'];
    function Service($http, $localStorage, toastr, serviceBasePath, $httpParamSerializerJQLike, $rootScope) {
        var config = { headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
        var config_post = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
        $http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.token;

        var service = {};
     
   
        service.upload = function (model, callback) {
            var request = new XMLHttpRequest();
            request.open("POST", serviceBasePath+ "api/snapshot/importFile");
            request.send(model);
            
            
        }
        service.Postdata = function(WC,SS_DOC,DOC,TYP, HasFormula,callback) {
            console.log()
            $http.post(serviceBasePath + 'api/tagging/AddTagged?WhsCode='+WC+'&DocEntry='+DOC +'&SS_DocEntry='+SS_DOC+'&Type_='+TYP+'&HasFormula='+HasFormula,{}, config_post)
            .then(function (response) {
                callback({ success: true});
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }  
        service.DeleteData = function(WC,SS_DOC,DOC,TYP, callback) {
            console.log()
            $http.delete(serviceBasePath + 'api/tagging/RemoveTagged?WhsCode='+WC+'&DocEntry='+DOC +'&SS_DocEntry='+SS_DOC+'&Type_='+TYP,{}, config_post)
            .then(function (response) {
                callback({ success: true});
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }   
        service.uploadRet = function(brnch,str, callback) {
            $http.post(serviceBasePath + 'api/snapshot/import?Brnch='+brnch +'&FileName='+str,{}, config_post)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }  
        service.getTagged = function(brnch,str, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetTagged?whcode='+brnch +'&docEntry='+str,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }
        service.GeRptTypeBS = function(brnch, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetBS?whcode='+brnch,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        } 

        service.GeRptTypeIS = function(brnch, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetIS?whcode='+brnch,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        } 
        service.GeRptTypeSS = function(brnch, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetSS?whcode='+brnch,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        } 
        service.GeAlltagged = function(docEntry,brnch, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetAllTagged?docEntry='+docEntry+'&whcode='+brnch,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }  
        service.GeAllDesc = function(brnch, callback) {
            $http.get(serviceBasePath + 'api/tagging/GetSSDesc?&whcode='+brnch,{}, config)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        } 
        service.RptType = function(callback) {
            var data = [
                {value: "IS", name: "IS"},
                {value: "BS", name: "BS"}
               ];
           callback({data: data});
        }

        service.uploadRet = function(brnch,str, callback) {
            $http.post(serviceBasePath + 'api/snapshot/import?Brnch='+brnch +'&FileName='+str,{}, config_post)
            .then(function (response) {
                callback({ success: true, data: response.data });
            },
            function (response) {
                toastr.error(response.data);
                callback({ success: false });
            }); 
        }    

        service.templates = function( callback) {
            $http.get(serviceBasePath + 'api/snapshot/getAllbranch',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });
        }
        service.dashboard = function( yr,callback) {
            $http.get(serviceBasePath + 'api/snapshot/dashboard?Yr='+yr,{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });
        }

        service.branch = function( callback) {
            $http.get(serviceBasePath + 'api/masterdata/branches',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }

        service.post = function(data, callback) {
           
            $http.post(serviceBasePath + 'api/snapshot/post',data, config_post)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        service.DuplicateTemp = function(str, str2,callback) {
           
            $http.post(serviceBasePath + 'api/snapshot/DuplicateTemp?Brnch='+str+'&BrnchTo='+str2,{}, config_post)
                .then(function (response) {
                    callback({ success: true });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        service.DeleteTemp = function(str, callback) {
           
            $http.delete(serviceBasePath + 'api/snapshot/DeleteTemp?Brnch='+str,{}, config_post)
                .then(function (response) {
                    callback({ success: true});
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        service.checkDup = function(str, callback) {
           
            $http.get(serviceBasePath + 'api/snapshot/CheckDuplicate?Brnch='+str,{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data});
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }



        service.year = function(callback) {
            var year = new Date().getFullYear()-10;
            var range = [];
               range.push(year);
               for (var i = 1; i < 21; i++) {
                   range.push(year + i);
               }
               console.log(range);
               callback(range);
   
               }

        return service;
    }
})();