(function () {
    'use strict';

    angular.module('app').factory('MasterDataService', Service)

    Service.$inject = ['$http', '$localStorage', 'toastr', 'serviceBasePath', '$httpParamSerializerJQLike', '$rootScope'];
    function Service($http, $localStorage, toastr, serviceBasePath, $httpParamSerializerJQLike, $rootScope) {
        var config = { headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
        var config_post = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
        $http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.token;

        var service = {};
        
        service.employees = function(callback) {
            $http.get(serviceBasePath + 'api/masterdata/employees', {}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                })
        }


        service.branches = function() {
            $http.get(serviceBasePath + 'api/masterdata/branches', {}, config_post)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                })
        }


    

        service.roles = function(callback) {
            var data = [
                {value: "USER", name: "Guest"},
                {value: "ADMIN", name: "Administrator"},
                {value: "MANAGER", name: "Manager"}
               ];
           callback({data: data});
        }
        

        return service;
    }
})();