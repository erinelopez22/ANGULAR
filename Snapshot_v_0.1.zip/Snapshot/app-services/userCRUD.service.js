(function () {
    'use strict';

    angular.module('app').factory('UserCRUDService', Service)

    Service.$inject = ['$http', '$localStorage', 'toastr', 'serviceBasePath', '$httpParamSerializerJQLike', '$rootScope'];
    function Service($http, $localStorage, toastr, serviceBasePath, $httpParamSerializerJQLike, $rootScope) {
        var config = { headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
        var config_post = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
        $http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.token;

        var service = {};
        
      
        service.AddUser = function(model, callback) {
            $http.post(serviceBasePath + 'api/users/AddUser',$httpParamSerializerJQLike(model), config_post)
                .then(function (response) {
                    callback({ success: true });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        service.GetUser = function( callback) {
            $http.get(serviceBasePath + 'api/users/get',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }



        service.UpdateUser = function(model, callback) {
            $http.put(serviceBasePath + 'api/users/UpdateUser',$httpParamSerializerJQLike(model), config_post)
                .then(function (response) {
                    callback({ success: true });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }

        service.DeleteUser = function(EmpCode_, callback) {
            $http.delete(serviceBasePath + 'api/users/DeleteUser?UserID='+EmpCode_+'',{}, config_post)
                
                .then(function (response) {
                    callback({ success: true });
                    console.log('api/users/DeleteUser?UserID='+EmpCode_+'');
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                    console.log(EmpCode_);
                 });

        }

        
        

        return service;
    }
})();