(function () {
    'use strict';

    angular.module('app').controller('FsController', Controller);
    
    Controller.$inject = ['FsService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope','serviceBasePath','$httpParamSerializerJQLike','$window'];
    function Controller( fs, toastr, $scope, $timeout, $location, $localStorage,$rootScope, path, serialize,$window) 
    {
        init();
        function init() {
            $scope.branch_ = "";
            $scope.year_ = "-Year-";
            $scope.year2_ = "-Year-";
            $scope.month_ = "";
            $scope.month2_ = "";
            Getyear();
            Getmonth();
            GetBranches();
        };

        $scope.dtopt = {
            paging: false,
            searching: false,
            scrollX: true,
           
            scrollY: true,
            
            info: false
            
        };

        $scope.ViewRpt=  function () {
            if($scope.year_=="-Year-" ){toastr.warning("Year is required"); $scope.loading = false; return;}
            if($scope.year2_=="-Year-" ){toastr.warning("Year is required"); $scope.loading = false; return;}
            if($scope.month_=="" ){toastr.warning(" Please select Month"); $scope.loading = false; return;}
            if($scope.month2_=="" ){toastr.warning(" Please select Month"); $scope.loading = false; return;}
            if($scope.branch_=="" ){toastr.warning("Branch is required"); $scope.loading = false; return;}
            // $scope.loading = true;
            $scope.loading = true;
            var Fromyear= $scope.year_;
            var Toyear= $scope.year2_;
            var pd1=  $scope.month_;
            var pd2=  $scope.month2_;
            var wc= $scope.branch_;

            fs.ViewReports(Fromyear,pd1,Toyear,pd2,wc,function(response) {
                if(response.success) {
                    $scope.BSRpts=response.data.BalSht;
                    $scope.HDR_=response.data.HDR;
                    $scope.ISRpts = response.data.IncState;
                    console.log($scope.BSRpts);
                    console.log($scope.ISRpts);
                    $scope.SSRpts = response.data.Snapshot;
                    $scope.loading = false;
                }
               

            });
        }
        $scope.Export=  function () {
            console.log(path + 'api/fs/export?' + serialize(params));
            if($scope.year_=="-Year-" ){toastr.warning("Year is required"); $scope.loading = false; return;}
            if($scope.year2_=="-Year-" ){toastr.warning("Year is required"); $scope.loading = false; return;}
            if($scope.month_=="" ){toastr.warning(" Please select Month"); $scope.loading = false; return;}
            if($scope.month2_=="" ){toastr.warning(" Please select Month"); $scope.loading = false; return;}
            if($scope.branch_=="" ){toastr.warning("Branch is required"); $scope.loading = false; return;}
            // $scope.loading = true;
           
            var Fromyear= $scope.year_;
            var Toyear= $scope.year2_;
            var pd1=  $scope.month_;
            var pd2=  $scope.month2_;
            var wc= $scope.branch_;

            var params = {
                Fromyear: Fromyear,
                pd1: pd1,
                Toyear: Toyear,
                pd2: pd2,
                whcode: wc
            }

            $window.open(path + 'api/fs/export?' + serialize(params), '_blank');

            // fs.export(Fromyear,pd1,Toyear,pd2,wc,function(response) {
            //     if(response.success) {
            //         console.log(response);
            //         toastr.success("Excel File Extracted");
            //         $scope.loading = false;
            //     }
            // });
        }

        function Getyear() {
            fs.year(function(response) {
                $scope.years = response;
                $scope.years.unshift("-Year-");
                
            });
        }
        function Getmonth() {
            fs.month(function(response) {
                $scope.months = response.data;
                $scope.months.unshift({value: "", name: "-Months-"});
            });
        }
        
        function GetBranches() {
            fs.branch(function(response) {
                $scope.branches = response.data;
                $scope.branches.unshift({BranchCode: "", BranchDscpt: "-Select Branch-"});
            });
        }
        
        
       
        
    }

})();