(function () {
    'use strict';

    angular.module('app').controller('SnapshotController', Controller);
    
    Controller.$inject = ['SnapshotService','UserCRUDService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope'];
    function Controller( ss, usr, toastr, $scope, $timeout, $location, $localStorage,$rootScope) 
    {
        init();
        function init() {
            
            GetBranches();
            GetTemplates();
            $scope.showMe = false;
            $scope.showMe2 = false;
            $scope.IsDuplicate=[];
            GetType();

            $scope.showval = false;
            $scope.showTbl=false;
       
        };
        $scope.Alldata_=[];
        $scope._Alldata='';
        $scope.SelDocEntry='';
        $scope.DOCUMENT_='';

        function GetTagged(Doc,WC,Hasform) {
            console.log(Doc+WC)
             ss.getTagged(WC,Doc,function(response) {
                 $scope.Rpter = response.data;
                 
                 $scope.DOCUMENT_ =  $scope.Rpter;
             });
         }

         function Exit() {
             
           $scope.showval = false;
         }
 
        $scope.isShow = function (index)
        {
            console.log($scope.Alldata_) ;
           var Descrip= $scope.Alldata_[index].Descrip;
           var Descrip2=$scope.Alldata_[index].DocEntry;
           var HasForm=$scope.Alldata_[index].ColBot
           $scope.SelDocEntry=$scope.Alldata_[index].DocEntry;
           $scope.myField = {};
            $scope.myField.label = Descrip;           
            $scope.docEn = {};
            $scope.docEn.label = Descrip2;     
            
            
           $scope.showval = true;
           console.log(HasForm+'PPPP');
           if(HasForm=='1'){$scope.checkboxEl=true}
           else if(HasForm=='0'){$scope.checkboxEl=false}
           else if(HasForm==''){$scope.checkboxEl=false}
           GetTagged(Descrip2,$scope.Temp_branch);
        
        }
        $scope.RemoveTagg = function (index)
        {
            var WC=$scope.Temp_branch;
            var SS_DOCENTRY=  $scope.SelDocEntry;
            var DOCENTRY=$scope.DOCUMENT_[index].DocEntry;
            var Type=$scope.DOCUMENT_[index].TBType;

            console.log(WC+'-'+SS_DOCENTRY+'-'+DOCENTRY+'-'+Type)
            

            ss.DeleteData(WC,SS_DOCENTRY,DOCENTRY,Type, function(response) {
            console.log(WC+SS_DOCENTRY+DOCENTRY+Type);
                if(response.success) {
                   
                    GetTagged(SS_DOCENTRY,WC)
                    Getalldesc2();
                    $scope.loading = false;
                    toastr.success("Remove Successfuly");
                }
                else{
                    
                    $scope.loading = false;
                    toastr.danger("Error in Removing tagged data ");
                }
            });
          
        }
        $scope.checkboxEl;
        $scope.AddTagg = function ()
        {
 
                var HasFormula=0;
                var WC=$scope.Temp_branch;
                var SS_DOCENTRY=  $scope.SelDocEntry;
                var DOCENTRY=$scope.descpt;
                var Type=$scope.TypeRpt;

                console.log(HasFormula+'-'+WC+'-'+SS_DOCENTRY+'-'+DOCENTRY+'-'+Type)
                
                if($scope.TypeRpt==undefined)
                {
                    if ($scope.checkboxEl) 
                    {
                            // HasFormula=0;
                            // WC=000;
                            // SS_DOCENTRY=  000;
                             DOCENTRY=111
                            Type=111
                            HasFormula=1;
                        ss.Postdata(WC,SS_DOCENTRY,DOCENTRY,Type,HasFormula, function(response) {
                           
                                if(response.success) {
                                    $scope.Alldata=response.data;
                                    $scope.Alldata_=response.data;
                                    GetTagged(SS_DOCENTRY,WC)
                                    Getalldesc2();
                                    $scope.loading = false;
                                    toastr.success("Tagged Successfuly");
                                }
                                else{
                                    
                                    $scope.loading = false;
                                    toastr.danger("Error in Tagging ");
                                }
                            });
                            return;
                    } 
                    else 
                    {
                        toastr.warning("Please Select Type");
                        return;
                    }  
                    
                }
                else if($scope.descpt==undefined)
                {
                  
                    if ($scope.checkboxEl) 
                    {   
                        // HasFormula=0;
                        // WC=000;
                        // SS_DOCENTRY=  000;
                        DOCENTRY=111
                        Type=111
                        
                        HasFormula=1;
                        ss.Postdata(WC,SS_DOCENTRY,DOCENTRY,Type,HasFormula, function(response) {
                            console.log(WC+SS_DOCENTRY+DOCENTRY+Type);
                                if(response.success) {
                                    $scope.Alldata=response.data;
                                    $scope.Alldata_=response.data;
                                    GetTagged(SS_DOCENTRY,WC)
                                    Getalldesc2();
                                    $scope.loading = false;
                                    toastr.success("Tagged Successfuly");
                                }
                                else{
                                    
                                    $scope.loading = false;
                                    toastr.danger("Error in Tagging ");
                                }
                            });
                            return;
                    } 
                    else 
                    {
                        
                        toastr.warning("Please Select Type");
                        return;
                    }   

                }
                if ($scope.checkboxEl) 
                    {   
                        // HasFormula=0;
                        // WC=000;
                        // SS_DOCENTRY=  000;
                        DOCENTRY=111
                        Type=111
                        
                        HasFormula=1;
                        ss.Postdata(WC,SS_DOCENTRY,DOCENTRY,Type,HasFormula, function(response) {
                            console.log(WC+SS_DOCENTRY+DOCENTRY+Type);
                                if(response.success) {
                                    $scope.Alldata=response.data;
                                    $scope.Alldata_=response.data;
                                    GetTagged(SS_DOCENTRY,WC)
                                    Getalldesc2();
                                    $scope.loading = false;
                                    toastr.success("Tagged Successfuly");
                                }
                                else{
                                    
                                    $scope.loading = false;
                                    toastr.danger("Error in Tagging ");
                                }
                            });
                            return;
                    } 
                    else 
                    {
                        HasFormula=0;
                        ss.Postdata(WC,SS_DOCENTRY,DOCENTRY,Type,HasFormula, function(response) {
                            console.log(WC+SS_DOCENTRY+DOCENTRY+Type);
                                if(response.success) {
                                    $scope.Alldata=response.data;
                                    $scope.Alldata_=response.data;
                                    GetTagged(SS_DOCENTRY,WC)
                                    Getalldesc2();
                                    $scope.loading = false;
                                    toastr.success("Tagged Successfuly");
                                }
                                else{
                                    
                                    $scope.loading = false;
                                    toastr.danger("Error in Tagging ");
                                }
                            });
                    } 
               
                
         
        }

        $scope.Getalldesc=function (){
          
        if($scope.Temp_branch==undefined)
        {
            toastr.warning("Pick Branch");
            return;
        }
        else
        {
            
           var wc=$scope.Temp_branch;
           console.log(wc);
                ss.GeAllDesc(wc, function(response) {
                    if(response.success) {
                        $scope.Alldata=response.data;
                        $scope.Alldata_=response.data;
                        if($scope.Alldata_.length==0){ $scope.showval = false;$scope.showTbl=false
                            toastr.warning("There is no template for the selected branch");
                            return;
                        }
                        else{ }
                
                        $scope.loading = false;
                    }
                    else{
                        toastr.danger("Error in Get all Descriptions");
                        $scope.loading = false;
                    }
                });
                $scope.loading = false;
                $scope.showTbl=true; 
            
            GetTemplates();
        }
        }
       function Getalldesc2(){
            var wc=$scope.Temp_branch;
                 ss.GeAllDesc(wc, function(response) {
                     if(response.success) {
                         $scope.Alldata=response.data;
                         $scope.Alldata_=response.data;
                         
                         $scope.loading = false;
                     }
                     else{
                         toastr.danger("Error in Get all Descriptions");
                         $scope.loading = false;
                     }
                 });
                 $scope.loading = false;
                 $scope.showTbl=true; 
             
             GetTemplates();
             
         }
       
        $scope.GetRpt = function ()
        {
           
            var BranchDesc= $scope. Temp_branch;
           
            var type_= $scope.TypeRpt;
            console.log( type_);
            if(type_=="IS"){
                ss.GeRptTypeIS(BranchDesc,function(response) {
                    if(response.success) {
                       $scope.dscp=response.data;
                     
                       console.log(response);
                       console.log(response.data);
                    }
                    
                });
            }
            else if(type_=="BS"){
            ss.GeRptTypeBS(BranchDesc,function(response) {
                if(response.success) {
                   $scope.dscp=response.data;
               
                   console.log(response);
                   console.log(response.data);
                }
                
            });
            }
            else if(type_=="SS"){
                ss.GeRptTypeSS(BranchDesc,function(response) {
                    if(response.success) {
                       $scope.dscp=response.data;
                   
                       console.log(response);
                       console.log(response.data);
                    }
                    
                });
            }
        }

        function GetType() {
            
            ss.RptType(function(response) {
                $scope.RptTypes = response.data;
            });
        }

        $scope.isHide = function ()
        {
            
                $scope.showval = false;
        }

        $scope.IsDuplicate=[];
        $scope.Upload=function () {
            $scope.loading = true;
            var formData = new FormData()
            var fileInput = document.getElementById('file');
         
            var brnch=$scope.IT_branch;
            if(brnch==undefined)
            {
                toastr.warning("Branch is required");
                console.log(fileInput.files.length);
                $scope.loading = false;
                return;
            }
            else if(fileInput.files.length==0)
            {
                toastr.warning("Please select file to be uploaded");
                console.log(fileInput.files.length);
                $scope.loading = false;
                return;
            }
            else
            {

                for ( var i = 0; i < fileInput.files.length; i++) {
                    formData.append(fileInput.files[i].name, fileInput.files[i]);
                }

                    ss.upload(formData, function(response) {});
                    ss.uploadRet(brnch,fileInput.files[0].name, function(response) {
                        if(response.success) {
                            console.log($scope.IsDuplicate)
                            CHeck_Dup(brnch);
                            $scope.loading = false;
                        }
                    });
                    
                    
                    GetTemplates();
                    
            }
      
        }

        $scope.UploadMdl=function () {
            $scope.loading = true;
            var formData = new FormData()
            var fileInput = document.getElementById('Actionfile');
         
            var brnch=$scope.SelectedBranch;
            if(brnch==undefined)
            {
                toastr.warning("Branch is required");
                console.log(fileInput.files.length);
                $scope.loading = false;
                return;
            }
            else if(fileInput.files.length==0)
            {
                toastr.warning("Please select file to be uploaded");
                console.log(fileInput.files.length);
                $scope.loading = false;
                return;
            }
            else
            {

                for ( var i = 0; i < fileInput.files.length; i++) {
                    formData.append(fileInput.files[i].name, fileInput.files[i]);
                }

                    ss.upload(formData, function(response) {});
                    ss.uploadRet(brnch,fileInput.files[0].name, function(response) {
                        if(response.success) {
                            console.log($scope.IsDuplicate)
                            CHeck_Dup(brnch);
                        }
                    });
                    
                    
                    GetTemplates();
                    
            }
      
        }
    
        $scope.dtopt = {
            paging: false,
            searching: false,
            scrollX: false,
            scrollY: false,
            info: false,
            columnDefs: [
                { targets: 0, width: "15em" }, //branch
                { targets: 1, width: "5em" }, //descrip
                { targets: 2, width: "5em" }, //year
                
            ]
        };

        function GetBranches() {
            ss.branch(function(response) {
                $scope.branches = response.data;
                
            });
        }
        $scope.SelectedBranch='';
        $scope.SelectedBranch2='';
        $scope.HasTemplateT=[];
        function GetTemplates() {
            ss.templates(function(response) {
               
                $scope.Templates = response.data;
               
                $scope.HasTemplate=[];
                angular.forEach($scope.Templates, function(value, key){
                  
                    var model={
                                BranchCode: value.Code,
                                Branch: value.blk,
                                Temp: Boolean(value.Temp == 'N/A') ? "" : "✔",
                                }

                    $scope.HasTemplate.push(model);

                });
                $scope.HasTemplateT=$scope.HasTemplate;
            });
        }
        $scope.selwc=function(index)
        {
            var selectindex = document.getElementById('snapBR').selectedIndex;
            var selectitem = document.getElementById('snapBR').options; // get the select list
            console.log(selectitem[selectindex].innerText);
            
           
                
                
        }
        $scope.action=function(index) {
            var HasTemplate = $scope.HasTemplateT[index].Temp;
            var TemplateBd = $scope.HasTemplateT[index].Branch;
            var TemplateBc = $scope.HasTemplateT[index].BranchCode;
            if(HasTemplate==""){
                $scope.showMe = true;
                $scope.showMe2 = false;
            }
            else{
                $scope.showMe = false;
                $scope.showMe2 = true;
            }

            $scope.SelectedBranch=TemplateBc;
            $scope.show1 = false;
            $scope.show2 = false;
            $scope.Add=  TemplateBd;  
            $scope.Addbranch=  TemplateBd;  
            $scope.SelectedBranch=TemplateBc;
            $scope.Dupbranch=  TemplateBd;  
            $scope.SelectedBranch2=TemplateBc;
            console.log($scope.HasTemplateT[index].BranchCode);
            $scope.DupbranchFrom =$scope.HasTemplateT[index].BranchCode;
            console.log($scope.DupbranchFrom+"asa");
            console.log($scope.SelectedBranch2+"__"+$scope.DupbranchFrom+"__"+$scope.Dupbranch+"__"+$scope.SelectedBranch)
            var mdl= document.getElementById('exampleModal');
            mdl.style.display="block";

        }
        
        var close1= document.getElementById('close1');
        close1.onclick = function(){
            var mdl= document.getElementById('exampleModal');
            mdl.style.display="none";
            GetTemplates();
        }
        var close2= document.getElementById('close2');
        close2.onclick = function(){
            var mdl= document.getElementById('exampleModal');
            mdl.style.display="none";
            GetTemplates();
        }

        
        $scope.AddTemp=function() {
            var brnch=$scope.loading = true;
            $scope.SelectedBranch='';
            var fileInput = document.getElementById('Actionfile');
            
            console.log(fileInput);
             if(fileInput.files.length==0)
            {
                toastr.warning("Please select file to be uploaded");
                console.log(fileInput.files.length);
                $scope.loading = false;
                return;
            }
            else
            {
                ss.upload(formData,brnch, function(response) {
                    if(response.success) {
                        toastr.success("File Uploaded successfuly");
                        $scope.loading = false;
                    }
                    else{
                        toastr.danger("Error in Uploading Templates");
                        $scope.loading = false;
                    }
                });
                $scope.loading = false;
                
            }
            GetTemplates();
            
        }
      
        function CHeck_Dup(brnchFrom) {
            $scope.loading = true;
            console.log('CHeckDup');
            var brnch= $scope.SelectedBranch2;
            
           
            ss.checkDup(brnchFrom, function(response) {
                if(response.success) {
                    if(response.data.length == 0)
                      {
                                toastr.warning("Unable to upload templates, Check File");
                                $scope.loading = false;
                            }
                            else
                            {
                                toastr.success("File Uploaded successfuly");
                                $scope.loading = false;
                            }
                }
                else{
                    toastr.danger("Unable to upload templates, Check File");
                    $scope.loading = false;
                }


            });
        }
        function CHeckDup(brnchFrom) {
            $scope.loading = true;
            console.log('CHeckDup');
            var brnch= $scope.SelectedBranch2;
            
           
            ss.checkDup(brnchFrom, function(response) {
                if(response.success) {
                    $scope.IsDup=response.data;
                    $scope.IsDuplicate=$scope.IsDup
                    $scope.loading = false;
                }
                else{
                    toastr.danger("Error in Checking duplicated Branch");
                    $scope.loading = false;
                }
            });
        }
        $scope.DuplicateTemp=function() {
            $scope.loading = true;
            var selectindex = document.getElementById('snapBR').selectedIndex;
            var selectitem = document.getElementById('snapBR').options;
            var brnch= $scope.SelectedBranch2;
            var brnchFrom=$scope.DupbranchFrom;
            var bDesc=selectitem[selectindex].innerText;
           
           
            console.log($scope.SelectedBranch2+"__"+$scope.DupbranchFrom+"__"+$scope.Dupbranch+"__"+$scope.SelectedBranch)
            console.log(brnch+'___'+brnchFrom)
            if(brnch==brnchFrom){toastr.warning($scope.Dupbranch +" already have template");
            $scope.loading = false;
            return;
            }

            ss.checkDup(brnchFrom, function(response) {
                if(response.success) {
                    $scope.IsDup=response.data;
                    $scope.IsDuplicate=$scope.IsDup
                    var aa= $scope.IsDuplicate.length;
                    if(aa ==0){
                        ss.DuplicateTemp(brnch,brnchFrom, function(response) {
                        if(response.success) {
                            toastr.success("Template successfuly duplicated");
                            $scope.loading = false;
                        }
                        else{
                            toastr.danger("Error in duplicating Templates");
                            $scope.loading = false;
                        }
                    });
                    GetTemplates();
                    }
                    
                    else{toastr.warning(bDesc +' '+' already have template')}
                    console.log($scope.DupbranchFrom);
                    $scope.loading = false;
                }
                else{
                    toastr.danger("Error in Checking duplicated Branch");
                    $scope.loading = false;
                }
            });
      
            
        }

        

        $scope.RemoveTemp=function() {
            $scope.loading = true;
            var brnch= $scope.SelectedBranch2;
            console.log('RemoveTemp');
            ss.DeleteTemp(brnch, function(response) {
                if(response.success) {
                    toastr.success("Template successfuly Removed");
                    $scope.loading = false;
                }
                else{
                    toastr.danger("Error in Removing Templates");
                    $scope.loading = false;
                }
                $scope.loading = false;
            });
            GetTemplates();
        }
        
        
    }


})();