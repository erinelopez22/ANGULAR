(function () {
    'use strict';

    angular.module('app').controller('PostingController', Controller);
    
    Controller.$inject = ['PostingService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope'];
    function Controller( ps, toastr, $scope, $timeout, $location, $localStorage,$rootScope) 
    {
        init();
        function init() {
 
            Getyear();
            Getmonth();
            GetBranches();
           
            $scope.Rpts = {}
            $scope.Rpts.header = {}
          
            $scope.Rpts.header.Yr = "-Year-";
            $scope.Rpts.header.Pd = "";
            $scope.Rpts.header.WhsCode = "";
            $scope.Rpts.BalSht={};
        };

       
        $scope.ViewRpt=  function () {
            $scope.loading = true;

            var Yr= $scope.Rpts.header.Yr;
            var Pd=  $scope.Rpts.header.Pd;
            var wc= $scope.Rpts.header.WhsCode;

            if(Yr=="")
            {
                toastr.warning("Year is required");
                $scope.loading = false;
                return;
            }
            else if(Pd=="")
            {
                toastr.warning("Months is required");
                $scope.loading = false;
                return;
            }
            else if(wc=="")
            {
                toastr.warning("Branch is required");
                $scope.loading = false;
                return;
            }
            else
            {
               console.log(Yr+'~'+Pd+'~'+wc)
                //$scope.IsDisabled=true;
             ps.ViewReports(Yr,Pd,wc,function(response) {
             if(response.success) {
                 $scope.Rpts.BalSht=response.data.BalSht;
                 $scope.Rpts.IncState=response.data.IncState;
                 $scope.BSRpts=response.data.BalSht;
                 $scope.ISRpts = response.data.IncState;
                 $scope.loading = false;
             }
            
             });
            
            }
           
        }

        $scope.dtopt = {
            paging: false,
            searching: false,
            scrollX: true,
            scrollY: "30em",
            info: false,
            columnDefs: [
                { targets: 0, width: "5em" }, //branch
                { targets: 1, width: "15em" }, //descrip
                { targets: 2, width: "3em" }, //year
                { targets: 3, width: "3em" }, //month
                { targets: 4, width: "5em" }, //Ctotal
            ]
        };
       
       

        $scope.post = function() {
            var CreatedBy=$localStorage.currentUser.EmpID;
            confirm({
                theme: 'material',
                icon: 'fa fa-question-circle', //CHANGE ICON
                closeIcon: true,
                title: 'Confirmation', //CHANGE TITLE
                content: 'Post data?', //CHANGE MESSAGE
                escapeKey: 'close',
                buttons: {
                    confirm: {
                        keys: ['enter'],
                        btnClass: 'btn-blue', //CHANGE COLOR
                        action: function() {
                            toastr.success("Successfuly Posted");
                            return
                        }
                    },
                    close: function() {
                        toastr.success("Unsuccessfuly Posted");
                            return
                    }
                }
            });

        }

      

        $scope.ViewRpt2=  function () {
            $scope.loading = true;
            var CreatedBy=$localStorage.currentUser.EmpID;
            var Yr= $scope.Rpts.header.Yr;
            var Pd=  $scope.Rpts.header.Pd;
            var wc= $scope.Rpts.header.WhsCode;
            console.log($scope.Rpts.BalSht.length)

            if(Yr=="")
            {
                toastr.warning("Year is required");
                $scope.loading = false;
                return;
            }
            else if(Pd=="")
            {
                toastr.warning("Months is required");
                $scope.loading = false;
                return;
            }
            else if(wc=="")
            {
                toastr.warning("Branch is required");
                $scope.loading = false;
                return;
            }
            else if( $scope.Rpts.BalSht.length==0)
            {
                toastr.warning("Please load a record");
                $scope.loading = false;
                return;
            }
            else if( $scope.Rpts.BalSht.length==undefined)
            {
                toastr.warning("Please load a record");
                $scope.loading = false;
                return;
            }
            else
            {
            
            ps.Add($scope.Rpts,function(response) {
                if(response.success) {
                    if(response.data==1)
                    { toastr.warning("Specific PERIOD,YEAR,BRANCH already Posted"); 
                    $scope.loading = false;
                    return;
                }
                   
                    $scope.$applyAsync();
                    toastr.success("Successfuly Posted");
                    $scope.loading = false;
                }
                $scope.loading = false;
            });
        }
        }

        function Getyear() {
            
            ps.year(function(response) {
                $scope.years = response;
                $scope.years.unshift("-Year-");
                
            });
        }
        function Getmonth() {
            ps.month(function(response) {
                $scope.months = response.data;
                $scope.months.unshift({value: "", name: "-Months-"});
            });
        }
        
        function GetBranches() {
            ps.branch(function(response) {
                $scope.branches = response.data;
                $scope.branches.unshift({BranchCode: "", BranchDscpt: "-Select Branch-"});
                
            });
        }
        
        
       
        
    }

})();