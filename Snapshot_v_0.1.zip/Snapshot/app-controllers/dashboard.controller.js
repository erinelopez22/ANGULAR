(function () {
    'use strict';

    angular.module('app').controller('DashboardController', Controller);
    
    Controller.$inject = ['SnapshotService','UserCRUDService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope'];
    function Controller( ss, usr, toastr, $scope, $timeout, $location, $localStorage,$rootScope) 
    {
        init();
        function init() {
            $scope.syear='2020';
            Getyear();
            Dashboard();
            
     

        };

        

        
       
        function Getyear() {
            console.log('asdasdas');
            ss.year(function(response) {
                $scope.years = response;
                
            });
        }
        
      
        function GetBranches() {
            ss.branch(function(response) {
                $scope.branches = response.data;
                
            });
        }
      
        function Dashboard() {
            $scope.loading = true;
            var yr=$scope.syear;
            console.log(yr);
            ss.dashboard(yr,function(response) {
                if(response.success) {
                    console.log('8888')
                    $scope.dash = response.data;
                    $scope.Templates = response.data;
                    }
                    $scope.loading = false;
                });
             
            }
     
            $scope.Dashboard1 = function() {
                $scope.loading = true;
                var yr=$scope.syear;
                console.log(yr);
                ss.dashboard(yr,function(response) {
                    if(response.success) {
                        console.log('8888')
                        $scope.dash = response.data;
                        $scope.Templates = response.data;
                        $scope.loading = false;
                        }
                        $scope.loading = false;
                    });
                 
            }

        
        
    }


})();