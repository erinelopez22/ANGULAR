(function () {
    'use strict';

    angular.module('app').controller('EmployeesController', Controller);


    Controller.$inject = ['$scope','$localStorage', 'serviceBasePath'];
    function Controller($scope,$localStorage, serviceBasePath) {

        init();

        function init() {
            $scope.sample = "TESTING";
            getdata();
        };

        function getdata() {
            $scope.model = [
                {id: 1, value: "one"},
                {id: 2, value: "two"},
                {id: 3, value: "three"},
            ];
        }
    }

})();