(function () {
    'use strict';

    angular.module('app').controller('UsersController', Controller);
    
    Controller.$inject = ['MasterDataService','UserCRUDService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope'];
    function Controller( mds, usr, toastr, $scope, $timeout, $location, $localStorage,$rootScope) 
    {
        init();
        function init() {
            getemployees();
            getroles();
            getusers();
            $scope.role = "USER";
        };

        function getemployees() {
            mds.employees(function(response) {
                if(response.success) {
                    $scope.employees = response.data;
                }
            });
        }

        function getusers() {
            usr.GetUser(function(response) {
                if(response.success) {
                    $scope.users = response.data;
                }
            });
        }

        function getroles() {
            mds.roles(function(response) {
                $scope.roles = response.data;
            });
        }

        $scope.add = function() {
            console.log($scope.role+$scope.searchemp);
           
            if($scope.searchEmp=='undefined')
            {toastr.warning("Role is required");
           
            $scope.loading = false;
            return;}
            else{
            var model = {
                EmpCode: $scope.employee.EmpCode,
                EmpName: $scope.employee.EmpName,
                Role: $localStorage.currentUser.UType,
                UType: $scope.role,
                CreatedBy:$localStorage.currentUser.EmpID,
                Approved: Boolean($localStorage.currentUser.UType == 'MANAGER') ? "Approved" : "For Approval",
                ApprovedBy: $localStorage.currentUser.UType == 'MANAGER' ? $localStorage.currentUser.EmpName : ""
            }
            console.log($localStorage.currentUser);

            usr.AddUser(model,function(response) {
                if(response.success) {
                    console.log(model);
                    $scope.users.push(model);
                    console.log($scope.users);
                    $scope.$applyAsync();
                    toastr.success("User added.");
                }
            });
        }
            
        }

        $scope.Edit=function(index) {
         var model = {
            EmpCode: $scope.users[index].EmpCode,
            UType: $scope.users[index].UType,
            ApprovedBy: $localStorage.currentUser.EmpID
        }
            usr.UpdateUser(model,function(response) {
                if(response.success) {
                    toastr.success("User Updated.");
                     getusers();
                }
            });
        }
        $scope.delete = function(index) {

            usr.DeleteUser($scope.users[index].EmpCode,function(response) {
                if(response.success) {
                    toastr.success("User Deleted.");
                     getusers();
                    $scope.users = $scope.users.filter(x => x.EmpCode != $scope.users[index].EmpCode);
                }
            });
        }

        



        
        

        $scope.selectEmp = function($item, $model, $label) {
            $scope.employee = $item;
            getusers();
        }
        
    }

})();