(function () {
    'use strict';

    angular.module('app').controller('LoginController', Controller);

    Controller.$inject = ['AuthenticationService', 'toastr', '$scope', '$timeout', '$location'];
    function Controller(as, toastr, $scope, $timeout, $location) {

        //scope variables
        $scope.username = '';
        $scope.password = '';

        //scope functions
        $scope.login = login;

        init();

        function init() {
            // reset login status
            as.Logout();
        };
        $scope.userAccess='';
        function login() {
            $scope.loading = true;
            as.Login($scope.username, $scope.password, function (result) {
                if (result.success == true) {
                    console.log('ee');
                    // $location.path('/');
                    $timeout(function () {
                        $location.path('/');
                    }, 300);
                } else {
                    console.log('ll');
                    $timeout(function () {
                        $location.path('/');
                    }, 300);
                }
            });
        };
        function CheckAccessRights(usr) {
            $scope.loading = true;
            as.CheckAccessRights(usr, function (result) {
                if (result.success == true) {
                        $scope.userAccess=response.data;
                } 
            });
        };
    }

})();