(function () {
    'use strict';

    angular.module('app').controller('PostingController', Controller);
    
    Controller.$inject = ['PostingService','toastr', '$scope', '$timeout', '$location', '$localStorage','$rootScope'];
    function Controller( ps, toastr, $scope, $timeout, $location, $localStorage,$rootScope) 
    {
        init();
        function init() {
 
            Getyear();
            Getmonth();
            GetBranches();
            $scope.year_ = "0000";
            $scope.month_ = "January";
          
        };

       
        $scope.ViewRpt=  function () {
            $scope.loading = true;

            var Yr= $scope.year_;
            var Pd=  $scope.month_;
            var wc= $scope.branch_;
            console.log(Yr+Pd+wc);
            if(Yr=='0000')
            {
                toastr.warning("Year is required");
                $scope.loading = false;
                return;
            }
            else if(Pd=='January')
            {
                toastr.warning("Months is required");
                $scope.loading = false;
                return;
            }
            else if(wc==undefined)
            {
                toastr.warning("Branch is required");
                $scope.loading = false;
                return;
            }
            else
            {
             ps.ViewReports(Yr,Pd,wc,function(response) {
             if(response.success) {
                 $scope.Rpts=response.data;
                 $scope.BSRpts=response.data.BalSht;
                 $scope.ISRpts = response.data.IncState;
                 $scope.loading = false;
             }
            
             });
            
            }
           
        }

        $scope.dtopt = {
            paging: false,
            searching: false,
            scrollX: true,
            scrollY: "30em",
            info: false,
            columnDefs: [
                { targets: 0, width: "5em" }, //branch
                { targets: 1, width: "15em" }, //descrip
                { targets: 2, width: "3em" }, //year
                { targets: 3, width: "3em" }, //month
                { targets: 4, width: "5em" }, //Btotal
                { targets: 5, width: "5em" }, //Etotal
                { targets: 6, width: "5em" }, //Ctotal
                { targets: 7, width: "5em" }, //Etotal
                { targets: 8, width: "5em" }, //Ctotal
            ]
        };
       
       

        $scope.post = function() {
            var CreatedBy=$localStorage.currentUser.EmpID;
            confirm({
                theme: 'material',
                icon: 'fa fa-question-circle', //CHANGE ICON
                closeIcon: true,
                title: 'Confirmation', //CHANGE TITLE
                content: 'Post data?', //CHANGE MESSAGE
                escapeKey: 'close',
                buttons: {
                    confirm: {
                        keys: ['enter'],
                        btnClass: 'btn-blue', //CHANGE COLOR
                        action: function() {
                            toastr.success("Successfuly Posted");
                            return
                        }
                    },
                    close: function() {
                        toastr.success("Unsuccessfuly Posted");
                            return
                    }
                }
            });

        }

       

        $scope.ViewRpt2=  function () {
            $scope.loading = true;
            var CreatedBy=$localStorage.currentUser.EmpID;
            ps.Add($scope.Rpts,CreatedBy,function(response) {
                if(response.success) {
                    $scope.$applyAsync();
                    toastr.success("Successfuly Posted");
                }
                $scope.loading = false;
            });
        }

        function Getyear() {
            
            ps.year(function(response) {
                $scope.years = response;
                
            });
        }
        function Getmonth() {
            ps.month(function(response) {
                $scope.months = response.data;
            });
        }
        
        function GetBranches() {
            ps.branch(function(response) {
                $scope.branches = response.data;
                
            });
        }
        
        
       
        
    }

})();