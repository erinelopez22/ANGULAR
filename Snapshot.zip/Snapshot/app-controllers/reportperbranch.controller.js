(function () {
    'use strict';

    angular.module('app').controller('ReportperbranchController', Controller);

    Controller.$inject = ['toastr', '$scope', '$timeout', '$location'];
    function Controller( toastr, $scope, $timeout, $location) {

       

        init();

        function init() {
            
        };

        
    }

})();