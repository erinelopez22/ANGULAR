(function () {
    'use strict';

    angular.module('app').factory('PostingService', Service)

    Service.$inject = ['$http', '$localStorage', 'toastr', 'serviceBasePath', '$httpParamSerializerJQLike', '$rootScope'];
    function Service($http, $localStorage, toastr, serviceBasePath, $httpParamSerializerJQLike, $rootScope) {
        var config = { headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
        var config_post = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
        $http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.token;

        var service = {};
     

        service.month = function(callback) {
            var data = [
                {value: "1", name: "January"},
                {value: "2", name: "February"},
                {value: "3", name: "March"},
                {value: "4", name: "April"},
                {value: "5", name: "May"},
                {value: "6", name: "June"},
                {value: "7", name: "July"},
                {value: "8", name: "August"},
                {value: "9", name: "September"},
                {value: "10", name: "October"},
                {value: "11", name: "November"},
                {value: "12", name: "December"}
               ];
           callback({data: data});
        }
        
        service.ViewReports = function( Yr,Pd,wc,callback) {
            $http.get(serviceBasePath + 'api/fs/get?Yr='+Yr+'&Pd='+Pd+'&whcode='+wc+'',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }

        service.branch = function( callback) {
            $http.get(serviceBasePath + 'api/masterdata/branches',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }

        service.year = function(callback) {
            var year = new Date().getFullYear()-10;
            var range = [];
               range.push(year);
               for (var i = 1; i < 21; i++) {
                   range.push(year + i);
               }
               console.log(range);
               callback(range);
   
               }

            
        
        service.Add = function(RPT,CreatedBy, callback) {
            console.log(RPT);
           
            $http.post(serviceBasePath + 'api/fs/postData?createdBy='+CreatedBy+'',$httpParamSerializerJQLike(RPT), config_post)
                .then(function (response) {
                    callback({ success: true });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        return service;
    }
})();