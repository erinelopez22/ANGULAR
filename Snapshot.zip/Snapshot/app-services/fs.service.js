(function () {
    'use strict';

    angular.module('app').factory('FsService', Service)

    Service.$inject = ['$http', '$localStorage', 'toastr', 'serviceBasePath', '$httpParamSerializerJQLike', '$rootScope'];
    function Service($http, $localStorage, toastr, serviceBasePath, $httpParamSerializerJQLike, $rootScope) {
        var config = { headers: { 'Content-Type': 'text/plain; charset=utf-8' } };
        var config_post = { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } };
        $http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.token;

        var service = {};
     

        service.month = function(callback) {
            var data = [
                {value: "1", name: "January"},
                {value: "2", name: "February"},
                {value: "3", name: "March"},
                {value: "4", name: "April"},
                {value: "5", name: "May"},
                {value: "6", name: "June"},
                {value: "7", name: "July"},
                {value: "8", name: "August"},
                {value: "9", name: "September"},
                {value: "10", name: "October"},
                {value: "11", name: "November"},
                {value: "12", name: "December"}
               ];
           callback({data: data});
        }
        
        service.ViewReports = function( Fromyear,pd1,Toyear,pd2,wc,callback) {
            $http.get(serviceBasePath + 'api/fs/view?Fromyear='+Fromyear+'&pd1='+pd1+'&Toyear='+Toyear+'&pd2='+pd2+'&whcode='+wc+'',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        
        service.export = function( Fromyear,pd1,Toyear,pd2,wc,callback) {
            $http.get(serviceBasePath + 'api/fs/export?Fromyear='+Fromyear+'&pd1='+pd1+'&Toyear='+Toyear+'&pd2='+pd2+'&whcode='+wc+'',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }
        service.branch = function( callback) {
            $http.get(serviceBasePath + 'api/masterdata/branches',{}, config)
                .then(function (response) {
                    callback({ success: true, data: response.data });
                },
                function (response) {
                    toastr.error(response.data);
                    callback({ success: false });
                 });

        }

        service.year = function(callback) {

         var year = new Date().getFullYear()-10;
         var range = [];
            range.push(year);
            for (var i = 1; i < 21; i++) {
                range.push(year + i);
            }
            console.log(range);
            callback(range);

            }

        return service;
    }
})();